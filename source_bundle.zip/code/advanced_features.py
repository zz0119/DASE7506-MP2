"""Bounded, reference-free arithmetic and group features for fixed candidates."""
import ast
from collections import Counter
from fractions import Fraction
import math
import re

import numpy as np

import features as baseline


FEATURE_VERSION = 3
FEATURE_NAMES = (
    'equations', 'checked_equations', 'correct_equations', 'wrong_equations',
    'checked_fraction', 'correct_fraction', 'wrong_fraction', 'residual_mean',
    'residual_max', 'exact_equations', 'equation_answer_matches',
    'last_equation_answer_match', 'fraction_marks', 'percent_marks',
    'division_marks', 'multiplication_marks', 'subtraction_marks',
    'question_numbers', 'unique_question_numbers', 'candidate_numbers',
    'unique_candidate_numbers', 'number_overlap_fraction',
    'candidate_numbers_from_question', 'answer_in_question',
    'answer_in_working', 'answer_in_pair_sum', 'answer_in_pair_difference',
    'answer_in_pair_product', 'answer_in_pair_quotient', 'answer_is_sum',
    'answer_is_mean', 'answer_is_min', 'answer_is_max', 'answer_is_integer',
    'answer_nonnegative', 'answer_magnitude', 'answer_over_question_max',
    'answer_over_question_sum', 'question_word_overlap',
    'question_word_coverage', 'answer_group_size', 'valid_answer_groups',
    'valid_candidates', 'answer_group_fraction', 'group_similarity_mean',
    'other_group_similarity_mean', 'group_similarity_difference',
    'same_answer_length_ratio', 'other_answer_length_ratio',
    'answer_log_distance_mean', 'answer_log_distance_min',
    'numeric_jaccard_mean', 'same_answer_numeric_jaccard',
    'other_answer_numeric_jaccard', 'question_has_percent',
    'question_has_money', 'question_has_average', 'question_has_rate',
    'question_has_remaining', 'question_has_total',
)
_BASE_DIM = 30
_NUMBER = re.compile(r'(?<![\w.])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?')
_MATH_EDGE = re.compile(r'[\d.\s+*/()\-]+')
_EQUALS = re.compile(r'(?<![<>=!])=(?!=)')
_FRACTION = re.compile(r'\\(?:dfrac|tfrac|frac)\s*\{([^{}]*)\}\s*\{([^{}]*)\}')
_WORDS = re.compile(r'[a-z]+')
_STOP = frozenset('a an the is are was were be to of and or in on at for by with how many much what he she it they his her their has have had does do did'.split())


def normalize_math(text):
    """Normalize common display notation, without interpreting arbitrary text."""
    text = str(text)[:24000]
    text = re.sub(r'\*\*([^*\n]+)\*\*', r'\1', text)
    text = text.replace('\u2212', '-').replace('\u00d7', '*').replace('\u00f7', '/')
    for old, new in (('\\times', '*'), ('\\cdot', '*'), ('\\div', '/'),
                     ('\\left', ''), ('\\right', ''), ('\\,', ''),
                     ('\\!', ''), ('\\%', '%')):
        text = text.replace(old, new)
    for _ in range(8):
        revised = _FRACTION.sub(r'((\1)/(\2))', text)
        if revised == text:
            break
        text = revised
    text = re.sub(r'\\(?:text|mathrm|operatorname)\s*\{([^{}]*)\}', r' \1 ', text)
    text = re.sub(r'\\boxed\s*\{([^{}]*)\}', r'(\1)', text)
    # Thousands separators have three-digit groups; a one/two digit suffix is decimal.
    text = re.sub(r'(?<=\d),(?=\d{3}(?:\D|$))', '', text)
    text = re.sub(r'(?<=\d),(?=\d{1,2}(?:\D|$))', '.', text)
    text = re.sub(r'(\d+(?:\.\d+)?)\s*%', r'(\1/100)', text)
    text = text.replace('^', '**').replace('{', '(').replace('}', ')')
    return text.replace('$', '').replace('\\[', '').replace('\\]', '').replace('\\(', '').replace('\\)', '')


def safe_arithmetic(expression):
    """Return an exact bounded Fraction or None; calls/names are never executed."""
    expression = str(expression).strip()
    if not expression or len(expression) > 180:
        return None
    try:
        tree = ast.parse(expression, mode='eval')
        if sum(1 for _ in ast.walk(tree)) > 64:
            return None

        def visit(node, depth=0):
            if depth > 12:
                raise ValueError('too deeply nested')
            if isinstance(node, ast.Constant) and type(node.value) in (int, float):
                literal = ast.get_source_segment(expression, node)
                if len(literal) > 40:
                    raise ValueError('large literal')
                value = Fraction(literal)
                if abs(value) > 10**15:
                    raise ValueError('large literal')
            elif isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
                value = visit(node.operand, depth+1)
                if isinstance(node.op, ast.USub):
                    value = -value
            elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow)):
                left, right = visit(node.left, depth+1), visit(node.right, depth+1)
                if isinstance(node.op, ast.Add):
                    value = left+right
                elif isinstance(node.op, ast.Sub):
                    value = left-right
                elif isinstance(node.op, ast.Mult):
                    value = left*right
                elif isinstance(node.op, ast.Div):
                    value = left/right
                else:
                    if right.denominator != 1 or abs(right) > 8:
                        raise ValueError('exponent outside bound')
                    value = left**int(right)
            else:
                raise ValueError('unsupported arithmetic')
            if abs(value) > 10**30 or value.numerator.bit_length() > 256 or value.denominator.bit_length() > 256:
                raise ValueError('arithmetic outside bound')
            return value

        return visit(tree.body)
    except (ValueError, SyntaxError, TypeError, ZeroDivisionError, OverflowError, RecursionError):
        return None


def _edge_value(text, left):
    matches = list(_MATH_EDGE.finditer(text))
    if not matches:
        return None
    match = matches[-1] if left else matches[0]
    outside = text[match.end():] if left else text[:match.start()]
    if outside.strip():
        return None
    remainder = text[:match.start()] if left else text[match.end():]
    if left:
        # A suffix of x+12 is not the expression 12; only explicit colon labels are safe.
        if remainder.strip() and not remainder.rstrip().endswith(':'):
            return None
    elif remainder:
        # Reject 3x and 3 x, while allowing a separated trailing unit such as "miles".
        if (remainder[0].isalnum() and not match.group()[-1].isspace()) or re.match(r'[a-zA-Z](?:\s|[+*/()\-]|$)', remainder):
            return None
    expression = match.group().strip().rstrip('.')
    return safe_arithmetic(expression)


def equation_evidence(normalized):
    """Check adjacent numeric expressions in equation chains; skip symbolic sides."""
    result = []
    count = 0
    normalized = re.sub(r'\\(?:Rightarrow|rightarrow|implies)|[\u21d2\u2192]', '\n', normalized)
    for line in normalized.splitlines():
        line = re.sub(r'^\s*[-*\u2022]\s+', '', line)
        pieces = _EQUALS.split(line)
        count += len(pieces)-1
        for left, right in zip(pieces, pieces[1:]):
            a, b = _edge_value(left, True), _edge_value(right, False)
            if a is not None and b is not None:
                right_math = _MATH_EDGE.match(right)
                right_unit = right[right_math.end():].strip() if right_math else ''
                # "2.50 = 250 cents" is a unit conversion, not a failed numeric identity.
                if right_unit and re.fullmatch(r'\s*[-+]?\d+(?:\.\d+)?\s*', left):
                    continue
                # A displayed percent after an explicit x100 uses the percentage number.
                if re.search(r'\*\s*100\s*$', left) and re.match(r'\s*\(\s*\d+(?:\.\d+)?/100\)', right):
                    b *= 100
                residual = float(abs(a-b)/(1+max(abs(a), abs(b))))
                result.append((a, b, residual))
            if len(result) >= 64:
                return count, result
    return count, result


def _numbers(text):
    values = []
    for match in _NUMBER.finditer(text):
        token = match.group()
        if len(token) > 30:
            continue
        try:
            value = float(token)
            if math.isfinite(value) and abs(value) <= 1e15:
                values.append(value)
        except ValueError:
            pass
        if len(values) >= 256:
            break
    return values


def _close(value, other):
    return abs(value-other) <= 1e-6*(1+abs(other))


def _jaccard(a, b):
    return len(a & b)/max(1, len(a | b))


def _pair_answers(numbers):
    answers = [[], [], [], []]
    for i, a in enumerate(numbers[:24]):
        for b in numbers[:24][i+1:]:
            answers[0].append(a+b)
            answers[1].extend((a-b, b-a))
            answers[2].append(a*b)
            if b:
                answers[3].append(a/b)
            if a:
                answers[3].append(b/a)
    return answers


def extract(bank, arrays):
    embeddings = np.asarray(arrays['embeddings'], dtype=np.float32)
    if embeddings.shape != (len(bank), 4, 1024) or not np.isfinite(embeddings).all():
        raise ValueError('Expected finite [N,4,1024] embeddings')
    if not bank:
        empty = np.empty((0, 4, _BASE_DIM), dtype=np.float32)
        features = {'embedding': embeddings, 'relative': embeddings.copy(),
                    'basic': empty, 'basic_relative': empty.copy(),
                    'advanced': np.empty((0, 4, len(FEATURE_NAMES)), dtype=np.float32),
                    'advanced_relative': np.empty((0, 4, len(FEATURE_NAMES)), dtype=np.float32),
                    'group_context': embeddings.copy()}
        return features, []
    features, answers = baseline.extract(bank, arrays)
    norms = np.linalg.norm(embeddings, axis=-1, keepdims=True)
    unit = embeddings/np.maximum(norms, 1e-8)
    similarities = unit @ unit.transpose(0, 2, 1)
    rows, contexts = [], []
    for q, row in enumerate(bank):
        texts = [candidate['text'] for candidate in row['candidates']]
        normalized = [normalize_math(t) for t in texts]
        question = normalize_math(row['question'])
        qnumbers = _numbers(question)
        qset = set(qnumbers)
        pairs = _pair_answers(qnumbers)
        numbers = [_numbers(t) for t in normalized]
        number_sets = [set(v) for v in numbers]
        qwords = set(_WORDS.findall(row['question'].lower()))-_STOP
        lengths = np.asarray([len(t) for t in texts], dtype=np.float64)
        valid = [a is not None for a in answers[q]]
        values = [float(Fraction(a)) if a is not None else 0. for a in answers[q]]
        counts = Counter(a for a in answers[q] if a is not None)
        group, group_context = [], []
        question_low = row['question'].lower()
        for j, text in enumerate(normalized):
            answer, value = answers[q][j], values[j]
            eqs, checked = equation_evidence(text)
            residuals = [x[2] for x in checked]
            correct = sum(r <= 1e-6 for r in residuals)
            final_matches = [valid[j] and _close(float(b), value) for _, b, _ in checked]
            original_body = texts[j].rsplit('####', 1)[0] if '####' in texts[j] else texts[j].rsplit('\\boxed', 1)[0]
            working = _numbers(normalize_math(original_body))
            same = [k for k in range(4) if valid[j] and answers[q][k] == answer]
            other = [k for k in range(4) if k != j and k not in same]
            peers = [k for k in range(4) if k != j]
            same_peers = [k for k in same if k != j]
            group_sim = float(similarities[q, j, same_peers].mean()) if same_peers else 0.
            other_sim = float(similarities[q, j, other].mean()) if other else 0.
            words = set(_WORDS.findall(text.lower()))-_STOP
            distances = [math.log1p(abs(value-values[k])) for k in other if valid[j] and valid[k]]
            relation = [valid[j] and any(_close(value, x) for x in candidates) for candidates in pairs]
            qsum = sum(qnumbers)
            qmax = max([abs(v) for v in qnumbers], default=0.)
            group.append([
                eqs, len(checked), correct, len(checked)-correct,
                len(checked)/max(1, eqs), correct/max(1, len(checked)),
                (len(checked)-correct)/max(1, len(checked)),
                np.mean(residuals) if residuals else 0., max(residuals, default=0.),
                sum(a == b for a, b, _ in checked), sum(final_matches),
                bool(final_matches and final_matches[-1]),
                texts[j].count('frac'), texts[j].count('%'), text.count('/'),
                text.count('*'), text.count('-'), len(qnumbers), len(qset),
                len(numbers[j]), len(number_sets[j]), len(qset & number_sets[j])/max(1, len(qset)),
                len(qset & number_sets[j])/max(1, len(number_sets[j])),
                valid[j] and any(_close(value, x) for x in qnumbers),
                valid[j] and any(_close(value, x) for x in working), *relation,
                valid[j] and bool(qnumbers) and _close(value, qsum),
                valid[j] and bool(qnumbers) and _close(value, qsum/len(qnumbers)),
                valid[j] and bool(qnumbers) and _close(value, min(qnumbers)),
                valid[j] and bool(qnumbers) and _close(value, max(qnumbers)),
                valid[j] and value.is_integer(), valid[j] and value >= 0,
                np.sign(value)*math.log1p(abs(value)),
                np.sign(value)*math.log1p(abs(value)/(1+qmax)),
                np.sign(value)*math.log1p(abs(value)/(1+abs(qsum))),
                len(words & qwords)/max(1, len(words)), len(words & qwords)/max(1, len(qwords)),
                counts.get(answer, 0), len(counts), sum(valid), counts.get(answer, 0)/max(1, sum(valid)),
                group_sim, other_sim, group_sim-other_sim,
                lengths[j]/max(1, lengths[same].mean()) if same else 0.,
                lengths[j]/max(1, lengths[other].mean()) if other else 0.,
                np.mean(distances) if distances else 0., min(distances, default=0.),
                np.mean([_jaccard(number_sets[j], number_sets[k]) for k in peers]),
                np.mean([_jaccard(number_sets[j], number_sets[k]) for k in same_peers]) if same_peers else 0.,
                np.mean([_jaccard(number_sets[j], number_sets[k]) for k in other]) if other else 0.,
                '%' in question_low or 'percent' in question_low,
                '$' in question_low or 'dollar' in question_low,
                'average' in question_low, any(s in question_low for s in ('per ', 'each ', 'rate', 'speed')),
                any(s in question_low for s in ('left', 'remain', 'rest ', 'after')),
                any(s in question_low for s in ('total', 'altogether', 'together', 'sum ')),
            ])
            same_mean = unit[q, same].mean(axis=0) if same else unit[q, j]
            other_mean = unit[q, other].mean(axis=0) if other else unit[q].mean(axis=0)
            group_context.append(same_mean-other_mean)
        rows.append(group)
        contexts.append(group_context)
    advanced = np.asarray(rows, dtype=np.float32)
    if advanced.shape[-1] != len(FEATURE_NAMES) or not np.isfinite(advanced).all():
        raise ValueError('Invalid arithmetic feature matrix')
    features.update(advanced=advanced,
                    advanced_relative=advanced-advanced.mean(axis=1, keepdims=True),
                    group_context=np.asarray(contexts, dtype=np.float32))
    return features, answers


def matrix(features, mode):
    if mode in ('embedding', 'style', 'combined'):
        return baseline.matrix(features, mode)
    if mode not in ('advanced', 'context', 'arithmetic'):
        raise ValueError(f'Unknown feature mode: {mode}')
    pieces = [features['advanced'], features['advanced_relative']]
    if mode != 'arithmetic':
        pieces.insert(0, baseline.matrix(features, 'combined'))
    if mode == 'context':
        pieces.append(features['group_context'])
    return np.concatenate(pieces, axis=-1)


def dimensions(features):
    return {mode: matrix(features, mode).shape[-1]
            for mode in ('embedding', 'style', 'combined', 'arithmetic', 'advanced', 'context')}
