"""Four-candidate attention ranker with NumPy-only checkpoint inference.

The torch model consumes standardized inputs. numpy_scores consumes raw features
and applies the train-fitted mean/scale stored by export.
"""
import numpy as np


ATTENTION_DIM = 64


def build_model(dim, width, dropout):
    """Construct the trainable model; importing this module does not import torch."""
    import torch
    from torch import nn

    if dim < 1 or width < 1 or not 0 <= dropout < 1:
        raise ValueError('Expected positive dimensions and dropout in [0,1)')

    class AttentionRanker(nn.Module):
        def __init__(self):
            super().__init__()
            self.first = nn.Linear(dim, width)
            self.drop = nn.Dropout(dropout)
            self.query = nn.Linear(width, ATTENTION_DIM, bias=False)
            self.key = nn.Linear(width, ATTENTION_DIM, bias=False)
            self.value = nn.Linear(width, ATTENTION_DIM, bias=False)
            self.attention_out = nn.Linear(ATTENTION_DIM, width)
            self.same_bias = nn.Parameter(torch.zeros(()))
            self.second = nn.Linear(3*width, 64)
            self.last = nn.Linear(64, 1)

        def forward(self, x, same):
            h = self.drop(torch.relu(self.first(x)))
            q, k, v = self.query(h), self.key(h), self.value(h)
            logits = (q @ k.transpose(-1, -2))*0.125 + self.same_bias*same
            attended = torch.softmax(logits, dim=-1) @ v
            h = torch.relu(h+self.attention_out(attended))
            group = h.mean(1, keepdim=True).expand_as(h)
            same_mean = (same @ h)/same.sum(-1, keepdim=True).clamp_min(1)
            context = torch.cat((h, group, same_mean-h), dim=-1)
            return self.last(torch.relu(self.second(context))).squeeze(-1)

    return AttentionRanker()


# Constructor-compatible with train.Ranker while keeping torch out of inference imports.
AttentionRanker = build_model


def export(model, mean, scale):
    """Export transposed float32 matrices and train-only preprocessing statistics."""
    weights = {'mean': np.array(mean, dtype=np.float32, copy=True),
               'scale': np.array(scale, dtype=np.float32, copy=True),
               'same_bias': model.same_bias.detach().cpu().numpy().copy()}
    for name, layer in (('first', model.first), ('query', model.query),
                        ('key', model.key), ('value', model.value),
                        ('attention_out', model.attention_out),
                        ('second', model.second), ('last', model.last)):
        weights[f'{name}_weight'] = layer.weight.detach().cpu().numpy().T.copy()
        if layer.bias is not None:
            weights[f'{name}_bias'] = layer.bias.detach().cpu().numpy().copy()
    if weights['mean'].ndim != 1 or weights['scale'].shape != weights['mean'].shape:
        raise ValueError('Expected one preprocessing statistic per input feature')
    if not all(np.isfinite(value).all() for value in weights.values()) or np.any(weights['scale'] <= 0):
        raise ValueError('Nonfinite weights or nonpositive preprocessing scale')
    return weights


def numpy_scores(x, same, weights):
    """Score [N,4,D] raw features using a frozen checkpoint and no torch import."""
    x = np.asarray(x, dtype=np.float32)
    same = np.asarray(same, dtype=np.float32)
    if x.ndim != 3 or x.shape[1] != 4 or same.shape != (*x.shape[:2], 4):
        raise ValueError('Expected [N,4,D] features and [N,4,4] answer mask')
    h = (x-weights['mean'])/weights['scale']
    h = np.maximum(h @ weights['first_weight']+weights['first_bias'], 0)
    q, k, v = (h @ weights[f'{name}_weight'] for name in ('query', 'key', 'value'))
    logits = (q @ k.transpose(0, 2, 1))*0.125 + weights['same_bias']*same
    logits -= logits.max(axis=-1, keepdims=True)
    attention = np.exp(logits)
    attention /= attention.sum(axis=-1, keepdims=True)
    attended = attention @ v
    h = np.maximum(h+attended @ weights['attention_out_weight']+weights['attention_out_bias'], 0)
    group = np.broadcast_to(h.mean(1, keepdims=True), h.shape)
    same_mean = (same @ h)/np.maximum(same.sum(-1, keepdims=True), 1)
    h = np.concatenate((h, group, same_mean-h), axis=-1)
    h = np.maximum(h @ weights['second_weight']+weights['second_bias'], 0)
    return (h @ weights['last_weight']+weights['last_bias'])[..., 0]
