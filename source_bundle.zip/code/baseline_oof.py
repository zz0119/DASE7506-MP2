"""Question-grouped OOF for the original, fixed-epoch BCE baseline recipe.

Unlike the newer ranker this preserves float32 moments, the 32-unit second
hidden layer, the original initialization/order, and unclipped AdamW updates.
Only supplied training/validation references can be opened by this module.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import time

for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[_key] = os.environ.get('MP2_TRAIN_THREADS', '2')

import numpy as np
import torch
from torch import nn

from common import DATA, load_inputs, parse_answer, read_jsonl
from features import extract, matrix, select


def labels(bank, split):
    if split not in ('train', 'validation'):
        raise ValueError('Baseline OOF may not read test references')
    references = read_jsonl(DATA / f'gsm8k_{split}.jsonl')
    if [row['id'] for row in references] != [row['id'] for row in bank]:
        raise ValueError('Reference alignment mismatch')
    return np.asarray([[parse_answer(candidate['text']) is not None and
                        parse_answer(candidate['text']) == parse_answer(reference['answer'])
                        for candidate in row['candidates']]
                       for row, reference in zip(bank, references)])


def fit_legacy(x, y, config, seed):
    """Fit exactly the original BCE baseline, without held-out model selection."""
    if config.get('objective') != 'bce' or config.get('kind') != 'mlp':
        raise ValueError('This reproducer supports original BCE MLP configurations only')
    mean = x.mean(axis=(0, 1))
    scale = x.std(axis=(0, 1)).clip(.01)
    z = torch.from_numpy((x-mean)/scale)
    target = torch.from_numpy(y.astype('float32'))
    torch.manual_seed(seed)
    width = config['width']
    model = nn.Sequential(nn.Linear(x.shape[-1], width), nn.ReLU(), nn.Dropout(.2),
                          nn.Linear(width, 32), nn.ReLU(), nn.Linear(32, 1))
    optimizer = torch.optim.AdamW(model.parameters(), lr=.0006,
                                 weight_decay=config['weight_decay'])
    for _ in range(config['epoch']):
        model.train()
        for indices in torch.randperm(len(y)).split(128):
            logits = model(z[indices]).squeeze(-1)
            loss = nn.functional.binary_cross_entropy_with_logits(logits, target[indices])
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
    weights = {'mean': mean.copy(), 'scale': scale.copy()}
    for k, layer in enumerate((model[0], model[3], model[5])):
        weights[f'w{k}'] = layer.weight.detach().numpy().T.copy()
        weights[f'b{k}'] = layer.bias.detach().numpy().copy()
    return weights


def score(x, weights):
    h = (x-weights['mean'])/weights['scale']
    for k in range(3):
        h = h @ weights[f'w{k}'] + weights[f'b{k}']
        if k != 2:
            h = np.maximum(h, 0)
    return h[..., 0]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_full_fit(x, y, config, config_path, output):
    """Compare the reproduced checkpoint and validation choices to the original."""
    start = time.perf_counter()
    weights = fit_legacy(x, y, config, config['seed'])
    with np.load(config_path.parent / config['weights'], allow_pickle=False) as archive:
        expected = {key: archive[key] for key in archive.files}
    errors = {key: float(np.max(np.abs(weights[key]-expected[key]))) for key in expected}
    close = all(np.allclose(weights[key], expected[key], atol=2e-4, rtol=2e-4) for key in expected)
    bank, arrays = load_inputs('validation')
    features, answers = extract(bank, arrays)
    vx = matrix(features, config['mode'])
    actual_scores, expected_scores = score(vx, weights), score(vx, expected)
    actual_choices = select(actual_scores, answers, config.get('pooling', 0.))
    expected_choices = select(expected_scores, answers, config.get('pooling', 0.))
    cached = config_path.with_name(config_path.stem + '-scores.npy')
    cached_error = None
    if cached.exists():
        cached_error = float(np.max(np.abs(expected_scores-np.load(cached, allow_pickle=False))))
    result = {'weight_max_abs_error': errors, 'weights_allclose_2e-4': close,
              'validation_score_max_abs_error': float(np.max(np.abs(actual_scores-expected_scores))),
              'original_checkpoint_vs_cached_scores_max_abs_error': cached_error,
              'validation_choices_equal': actual_choices == expected_choices,
              'validation_choice_disagreements': sum(a != b for a, b in zip(actual_choices, expected_choices)),
              'seconds': time.perf_counter()-start, 'threads': torch.get_num_threads(),
              'fit_scope': 'all supplied train rows only; validation inputs used after fitting'}
    (output / f'{config_path.stem}-full-fit-verification.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'full_fit_verification': result}), flush=True)
    if not close or not result['validation_choices_equal']:
        raise ValueError('Legacy reproduction does not match the original checkpoint/choices')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=Path('runs/oof'))
    parser.add_argument('--verify-full-fit', action='store_true')
    args = parser.parse_args()
    torch.set_num_threads(int(os.environ.get('MP2_TRAIN_THREADS', '2')))
    torch.set_num_interop_threads(1)
    config = json.loads(args.config.read_text())
    args.output.mkdir(parents=True, exist_ok=True)
    bank, arrays = load_inputs('train')
    features, answers = extract(bank, arrays)
    x, y = matrix(features, config['mode']), labels(bank, 'train')
    verification = verify_full_fit(x, y, config, args.config, args.output) if args.verify_full_fit else None
    from sklearn.model_selection import StratifiedKFold
    hard = np.array([len({a for a in row if a is not None}) >= 2 for row in answers])
    strata = hard.astype(int)*5 + y.sum(axis=1)
    splitter = StratifiedKFold(3, shuffle=True, random_state=17)
    predictions = np.empty(y.shape, dtype=np.float32)
    records = []
    start = time.perf_counter()
    for fold, (training, holdout) in enumerate(splitter.split(x, strata)):
        tick = time.perf_counter()
        weights = fit_legacy(x[training], y[training], config, config['seed']+fold)
        predictions[holdout] = score(x[holdout], weights)
        records.append({'fold': fold, 'seed': config['seed']+fold,
                        'train_questions': len(training), 'holdout_questions': len(holdout),
                        'holdout_indices_sha256': hashlib.sha256(holdout.astype('<i8').tobytes()).hexdigest(),
                        'seconds': time.perf_counter()-tick})
        print(json.dumps(records[-1]), flush=True)
    choices = select(predictions, answers)
    hits = y[np.arange(len(y)), choices]
    np.save(args.output / f'{args.config.stem}-oof.npy', predictions)
    record = {'source_config': str(args.config), 'source_config_sha256': digest(args.config),
              'source_weights_sha256': digest(args.config.parent/config['weights']),
              'fit_scope': 'train-only, question-grouped three-fold OOF; train-fold float32 normalization',
              'split': 'train', 'fold_seed': 17, 'epoch': config['epoch'], 'folds': records,
              'seconds': time.perf_counter()-start, 'threads': torch.get_num_threads(),
              'metrics': {'correct': int(hits.sum()), 'n': len(y), 'accuracy': float(100*hits.mean()),
                          'hard_correct': int(hits[hard].sum()), 'hard_n': int(hard.sum()),
                          'hard_accuracy': float(100*hits[hard].mean())},
              'full_fit_verification': verification}
    (args.output / f'{args.config.stem}-oof.json').write_text(json.dumps(record, indent=2)+'\n')


if __name__ == '__main__':
    main()
