"""Train-only text and structural selectors with portable NumPy assets.

Scoring imports neither sklearn nor scipy. Training uses their pinned versions.
"""
import argparse
from collections import Counter
import json
import os
from pathlib import Path
import re
import time

import numpy as np


TOKEN = re.compile(r"(?u)\b\w\w+\b")


def documents(bank, channel):
    docs = []
    for row in bank:
        for candidate in row['candidates']:
            text = candidate['text']
            answer = text.rsplit('####', 1)[-1] if '####' in text else text[-180:]
            if channel == 'full':
                docs.append(text)
            elif channel == 'question_answer':
                docs.append(row['question'] + '\n final answer ' + answer)
            elif channel == 'answer':
                docs.append(answer)
            else:
                raise ValueError(f'Unknown text channel: {channel}')
    return docs


def terms(text, ngram_max=2):
    words = TOKEN.findall(text.lower())
    if ngram_max == 1:
        return Counter(words)
    return Counter(words + [a + ' ' + b for a, b in zip(words, words[1:])])


def structural(bank, arrays, features, mode):
    if mode == 'basic':
        return np.concatenate([features['basic'], features['basic_relative']], axis=-1)
    if mode == 'advanced':
        import advanced_features as advanced
        value = features if 'advanced' in features else advanced.extract(bank, arrays)[0]
        return np.concatenate([value['basic'], value['basic_relative'],
                               advanced.matrix(value, 'arithmetic')], axis=-1)
    raise ValueError(f'Unknown structural mode: {mode}')


def score_text(docs, config, weights):
    vocabulary = config['vocabulary']
    idf = weights['idf']
    coef = weights['text_weights']
    result = np.empty(len(docs), dtype=np.float32)
    for i, doc in enumerate(docs):
        counts = terms(doc, config.get('ngram_max', 2))
        total, square = 0., 0.
        for word, count in counts.items():
            position = vocabulary.get(word)
            if position is None:
                continue
            tf = 1. + np.log(count) if config['sublinear_tf'] else count
            value = tf * float(idf[position])
            total += value * float(coef[position])
            square += value * value
        result[i] = float(weights['intercept'][0]) + total / max(np.sqrt(square), 1e-20)
    return result


def score_trees(x, weights):
    x = np.asarray(x, dtype=np.float32)
    result = np.full(len(x), float(weights['baseline'][0]), dtype=np.float64)
    # Each exported tree stores sklearn's already learning-rate-scaled leaf values.
    for tree in range(int(weights['tree_count'][0])):
        nodes = weights[f'tree{tree}']
        positions = np.zeros(len(x), dtype=np.int32)
        active = np.ones(len(x), dtype=bool)
        while active.any():
            rows = np.flatnonzero(active)
            selected = nodes[positions[rows]]
            leaves = selected['is_leaf'].astype(bool)
            if leaves.any():
                result[rows[leaves]] += selected['value'][leaves]
                active[rows[leaves]] = False
            rows, selected = rows[~leaves], selected[~leaves]
            if not len(rows):
                continue
            values = x[rows, selected['feature']]
            left = np.where(np.isnan(values), selected['missing_left'].astype(bool),
                            values <= selected['threshold'])
            positions[rows] = np.where(left, selected['left'], selected['right'])
    return result.astype(np.float32)


def fit_projection(embeddings, dimensions, seed):
    from sklearn.decomposition import PCA
    x = embeddings.reshape(-1, embeddings.shape[-1])
    model = PCA(n_components=dimensions, svd_solver='randomized',
                random_state=seed, iterated_power=3).fit(x)
    return dict(pca_mean=model.mean_.astype(np.float32),
                pca_components=model.components_.astype(np.float32))


def projected_structure(x, embeddings, weights):
    if 'pca_components' not in weights:
        return x
    p = (embeddings - weights['pca_mean']) @ weights['pca_components'].T
    return np.concatenate([x, p, p - p.mean(axis=1, keepdims=True)], axis=-1)


def score_member(bank, arrays, features, answers, config, basepath):
    """Return candidate logits [N,4] using only the supplied inference inputs."""
    del answers
    if len(bank) == 0:
        return np.empty((0, 4), dtype=np.float32)
    basepath = Path(basepath).resolve()
    weight_path = (basepath / config['weights']).resolve()
    if not weight_path.is_relative_to(basepath):
        raise ValueError('Inference weights must remain inside the asset directory')
    with np.load(weight_path, allow_pickle=False) as archive:
        weights = {key: archive[key] for key in archive.files}
    if config['kind'] == 'text':
        scores = score_text(documents(bank, config['channel']), config, weights)
        if config.get('struct_mode'):
            x = structural(bank, arrays, features, config['struct_mode'])
            x = x.reshape(-1, x.shape[-1])
            scores += ((x - weights['mean']) / weights['scale']) @ weights['struct_weights']
    elif config['kind'] == 'tree':
        x = structural(bank, arrays, features, config['struct_mode'])
        x = projected_structure(x, arrays['embeddings'], weights)
        scores = score_trees(x.reshape(-1, x.shape[-1]), weights)
    else:
        raise ValueError(f"Unknown complementary model: {config['kind']}")
    return scores.reshape(len(bank), 4)


def score(bank, arrays, config_path, features=None):
    """Convenience adapter for a standalone exported configuration file."""
    if features is None:
        from features import extract
        features, answers = extract(bank, arrays)
    else:
        answers = None
    config_path = Path(config_path)
    config = json.loads(config_path.read_text())
    return score_member(bank, arrays, features, answers, config, config_path.parent)


def export_trees(model):
    dtype = np.dtype([('feature', '<i4'), ('threshold', '<f8'), ('value', '<f8'),
                      ('left', '<i4'), ('right', '<i4'), ('missing_left', 'u1'),
                      ('is_leaf', 'u1')])
    result = {'baseline': model._baseline_prediction.ravel().astype(np.float64),
              'tree_count': np.asarray([len(model._predictors)], dtype=np.int32)}
    for i, group in enumerate(model._predictors):
        source = group[0].nodes
        if np.any(source['is_categorical']):
            raise ValueError('Categorical trees are not supported by this exporter')
        nodes = np.empty(len(source), dtype=dtype)
        for dst, src in [('feature', 'feature_idx'), ('threshold', 'num_threshold'),
                         ('value', 'value'), ('left', 'left'), ('right', 'right'),
                         ('missing_left', 'missing_go_to_left'), ('is_leaf', 'is_leaf')]:
            nodes[dst] = source[src]
        result[f'tree{i}'] = nodes
    return result


def labels(bank, split):
    from common import DATA, parse_answer, read_jsonl
    if split not in ('train', 'validation'):
        raise ValueError('Training and development may only read train/validation labels')
    refs = read_jsonl(DATA / f'gsm8k_{split}.jsonl')
    if [r['id'] for r in refs] != [r['id'] for r in bank]:
        raise ValueError('Reference ordering mismatch')
    return np.asarray([[parse_answer(c['text']) is not None and
                        parse_answer(c['text']) == parse_answer(ref['answer'])
                        for c in row['candidates']] for row, ref in zip(bank, refs)])


def fit_recipe(bank, x, y, config, seed, embeddings=None):
    """Fit one recipe; all fitted vocabulary/scaling uses only these rows."""
    if config['kind'] == 'tree':
        from sklearn.ensemble import HistGradientBoostingClassifier
        projection = {}
        if config.get('pca_dimensions'):
            projection = fit_projection(embeddings, config['pca_dimensions'], seed)
            grouped = x.reshape(len(bank), 4, -1)
            x = projected_structure(grouped, embeddings, projection).reshape(len(bank) * 4, -1)
        model = HistGradientBoostingClassifier(max_iter=config['iterations'],
            max_leaf_nodes=config['leaves'], min_samples_leaf=35,
            learning_rate=config['learning_rate'], l2_regularization=config['l2'],
            early_stopping=False, random_state=seed).fit(x, y.ravel())
        return dict(config), dict(export_trees(model), **projection)
    from scipy import sparse
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.linear_model import LogisticRegression
    vectorizer = TfidfVectorizer(max_features=16000, ngram_range=(1, 2), min_df=3,
                                 sublinear_tf=True, dtype=np.float32)
    text = vectorizer.fit_transform(documents(bank, config['channel']))
    mean, scale = x.mean(axis=0), x.std(axis=0).clip(.01)
    trainx = sparse.hstack([text, sparse.csr_matrix((x - mean) / scale)],
                           format='csr') if config.get('struct_mode') else text
    model = LogisticRegression(C=config['C'], solver='lbfgs', max_iter=400,
                               random_state=seed).fit(trainx, y.ravel())
    coef, dim = model.coef_[0].astype(np.float32), len(vectorizer.vocabulary_)
    weights = {'idf': vectorizer.idf_.astype(np.float32), 'text_weights': coef[:dim],
               'intercept': model.intercept_.astype(np.float32)}
    fitted = dict(config)
    fitted['vocabulary'] = {k: int(v) for k, v in vectorizer.vocabulary_.items()}
    if config.get('struct_mode'):
        weights.update(mean=mean, scale=scale, struct_weights=coef[dim:])
    return fitted, weights


def oof(args):
    from common import load_inputs
    from features import extract
    from sklearn.model_selection import KFold
    from threadpoolctl import threadpool_limits
    config = json.loads(args.oof_config.read_text())
    bank, arrays = load_inputs('train')
    f, _ = extract(bank, arrays)
    mode = config.get('struct_mode') or 'basic'
    x = structural(bank, arrays, f, mode)
    y = labels(bank, 'train')
    output = np.empty(y.shape, dtype=np.float32)
    splitter = KFold(n_splits=args.folds, shuffle=True, random_state=args.seed)
    tick = time.perf_counter()
    records = []
    with threadpool_limits(limits=2):
        for fold, (train, holdout) in enumerate(splitter.split(bank)):
            start = time.perf_counter()
            fitted, weights = fit_recipe([bank[i] for i in train],
                x[train].reshape(-1, x.shape[-1]), y[train], config, args.seed + fold,
                embeddings=arrays['embeddings'][train])
            if fitted['kind'] == 'tree':
                held_x = projected_structure(x[holdout], arrays['embeddings'][holdout], weights)
                s = score_trees(held_x.reshape(-1, held_x.shape[-1]), weights)
            else:
                s = score_text(documents([bank[i] for i in holdout], fitted['channel']), fitted, weights)
                if fitted.get('struct_mode'):
                    z = (x[holdout].reshape(-1, x.shape[-1]) - weights['mean']) / weights['scale']
                    s += z @ weights['struct_weights']
            output[holdout] = s.reshape(-1, 4)
            records.append(dict(fold=fold, train_questions=len(train),
                                holdout_questions=len(holdout), seconds=time.perf_counter() - start))
            print(json.dumps(records[-1]), flush=True)
    stem = args.oof_config.stem
    np.save(args.output / f'{stem}-oof.npy', output)
    (args.output / f'{stem}-oof.json').write_text(json.dumps(dict(
        source_config=str(args.oof_config), seed=args.seed, folds=args.folds,
        split='train', seconds=time.perf_counter() - tick, records=records), indent=2))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, default=Path('runs/complementary'))
    p.add_argument('--phase', choices=['text', 'trees', 'all'], default='all')
    p.add_argument('--struct-mode', choices=['basic', 'advanced'], default='basic')
    p.add_argument('--seed', type=int, default=137)
    p.add_argument('--oof-config', type=Path)
    p.add_argument('--folds', type=int, default=3)
    p.add_argument('--pca-dimensions', type=int, choices=[64, 128])
    args = p.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    if args.oof_config is not None:
        oof(args)
        return
    from common import load_inputs
    from features import extract, select
    from threadpoolctl import threadpool_limits
    bank, arrays = load_inputs('train')
    vbank, varrays = load_inputs('validation')
    f, _ = extract(bank, arrays)
    vf, answers = extract(vbank, varrays)
    y, vy = labels(bank, 'train'), labels(vbank, 'validation')
    hard = np.array([len(set(a for a in row if a is not None)) >= 2 for row in answers])
    tx = structural(bank, arrays, f, args.struct_mode)
    vx = structural(vbank, varrays, vf, args.struct_mode)
    tx, vx = tx.reshape(-1, tx.shape[-1]), vx.reshape(-1, vx.shape[-1])

    def save(name, config, weights, scores, tick):
        np.savez(out / f'{name}.npz', **weights)
        config.update(name=name, weights=f'{name}.npz', seed=args.seed)
        if config.get('struct_mode') == 'advanced':
            config['feature_version'] = 3
        (out / f'{name}.json').write_text(json.dumps(config, separators=(',', ':')))
        exported = score_member(vbank, varrays, vf, answers, config, out)
        max_error = float(np.max(np.abs(exported - scores)))
        if not np.allclose(exported, scores, atol=2e-4, rtol=2e-4):
            raise AssertionError(f'Export mismatch for {name}: {max_error}')
        best = None
        for pooling in (0., .5, 1.):
            choices = select(exported, answers, pooling)
            hit = vy[np.arange(len(vy)), choices]
            record = dict(name=name, pooling=pooling, correct=int(hit.sum()),
                          accuracy=float(100 * hit.mean()), n=len(hit),
                          hard_correct=int(hit[hard].sum()), hard_n=int(hard.sum()),
                          hard_accuracy=float(100 * hit[hard].mean()),
                          kind=config['kind'], struct_mode=config.get('struct_mode'),
                          fit_seconds=time.perf_counter() - tick, export_max_error=max_error,
                          asset_bytes=(out / f'{name}.npz').stat().st_size +
                                      (out / f'{name}.json').stat().st_size)
            with (out / 'experiments.jsonl').open('a') as log:
                log.write(json.dumps(record) + '\n')
            if best is None or (record['hard_correct'], record['correct']) > (best['hard_correct'], best['correct']):
                best = record
        config['pooling'] = best['pooling']
        (out / f'{name}.json').write_text(json.dumps(config, separators=(',', ':')))
        np.save(out / f'{name}-scores.npy', exported)
        print(json.dumps(best), flush=True)

    with threadpool_limits(limits=2):
        if args.phase in ('text', 'all'):
            from scipy import sparse
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.linear_model import LogisticRegression
            mean, scale = tx.mean(axis=0), tx.std(axis=0).clip(.01)
            z, vz = (tx - mean) / scale, (vx - mean) / scale
            for channel in ('full', 'question_answer', 'answer'):
                tick = time.perf_counter()
                vectorizer = TfidfVectorizer(max_features=16000, ngram_range=(1, 2),
                                             min_df=3, sublinear_tf=True, dtype=np.float32)
                text = vectorizer.fit_transform(documents(bank, channel))
                vtext = vectorizer.transform(documents(vbank, channel))
                for include_struct in (False, True):
                    x = sparse.hstack([text, sparse.csr_matrix(z)], format='csr') if include_struct else text
                    testx = sparse.hstack([vtext, sparse.csr_matrix(vz)], format='csr') if include_struct else vtext
                    for c in (.03, .3, 3.):
                        tick = time.perf_counter()
                        model = LogisticRegression(C=c, solver='lbfgs', max_iter=400,
                                                   random_state=args.seed).fit(x, y.ravel())
                        coef = model.coef_[0].astype(np.float32)
                        dim = len(vectorizer.vocabulary_)
                        weights = {'idf': vectorizer.idf_.astype(np.float32),
                                   'text_weights': coef[:dim],
                                   'intercept': model.intercept_.astype(np.float32)}
                        config = dict(kind='text', channel=channel, ngram_max=2, sublinear_tf=True,
                                      vocabulary={k: int(v) for k, v in vectorizer.vocabulary_.items()},
                                      C=c, struct_mode=args.struct_mode if include_struct else None)
                        if include_struct:
                            weights.update(mean=mean, scale=scale, struct_weights=coef[dim:])
                        suffix = args.struct_mode if include_struct else 'plain'
                        name = f'text-{channel}-{suffix}-{c}'
                        save(name, config, weights, model.decision_function(testx).reshape(-1, 4), tick)
        if args.phase in ('trees', 'all'):
            from sklearn.ensemble import HistGradientBoostingClassifier
            projection = {}
            if args.pca_dimensions:
                projection = fit_projection(arrays['embeddings'], args.pca_dimensions, args.seed)
                tx = projected_structure(tx.reshape(len(bank), 4, -1), arrays['embeddings'], projection)
                vx = projected_structure(vx.reshape(len(vbank), 4, -1), varrays['embeddings'], projection)
                tx, vx = tx.reshape(len(bank) * 4, -1), vx.reshape(len(vbank) * 4, -1)
            for leaves, l2 in ((7, 10.), (15, 10.), (31, 10.), (15, 100.)):
                for iterations in (100, 250, 500):
                    tick = time.perf_counter()
                    model = HistGradientBoostingClassifier(max_iter=iterations, max_leaf_nodes=leaves,
                        min_samples_leaf=35, learning_rate=.06, l2_regularization=l2,
                        early_stopping=False, random_state=args.seed).fit(tx, y.ravel())
                    mode = args.struct_mode + (f'-pca{args.pca_dimensions}' if args.pca_dimensions else '')
                    name = f'tree-{mode}-{leaves}-{l2}-{iterations}'
                    save(name, dict(kind='tree', struct_mode=args.struct_mode, leaves=leaves,
                                    l2=l2, iterations=iterations, learning_rate=.06,
                                    pca_dimensions=args.pca_dimensions),
                         dict(export_trees(model), **projection),
                         model.decision_function(vx).reshape(-1, 4), tick)


if __name__ == '__main__':
    main()
