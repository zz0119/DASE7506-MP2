"""Fit nonnegative fusion on training OOF logits; select using validation only."""
import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from scipy.optimize import minimize
from scipy.special import logsumexp

from common import load_inputs
from features import extract, select


def targets(bank, split):
    from common import DATA, parse_answer, read_jsonl
    if split not in ('train', 'validation'):
        raise ValueError('Ensemble development cannot read test references')
    refs = read_jsonl(DATA/f'gsm8k_{split}.jsonl')
    assert [r['id'] for r in bank] == [r['id'] for r in refs]
    return np.array([[parse_answer(c['text']) is not None and
                      parse_answer(c['text']) == parse_answer(r['answer'])
                      for c in row['candidates']] for row, r in zip(bank, refs)])


def evaluate(scores, answers, y, pooling=0.):
    hit = y[np.arange(len(y)), select(scores, answers, pooling)]
    hard = np.array([len({v for v in a if v is not None}) >= 2 for a in answers])
    return dict(correct=int(hit.sum()), n=len(y), accuracy=float(100*hit.mean()),
                hard_correct=int(hit[hard].sum()), hard_n=int(hard.sum()),
                hard_accuracy=float(100*hit[hard].mean()))


def discover(directories):
    candidates = []
    for directory in directories:
        for path in sorted(Path(directory).glob('*.json')):
            config = json.loads(path.read_text())
            scores = path.with_name(path.stem+'-scores.npy')
            if not scores.exists() or 'weights' not in config or 'mode' not in config and 'kind' not in config:
                continue
            candidates.append((path, config, np.load(scores, allow_pickle=False)))
    return candidates


def optimize(oof, y, hard, l2=.01, objective='set'):
    scale = np.std(oof-oof.mean(axis=-1, keepdims=True), axis=(1, 2)).clip(.05)
    z = np.moveaxis((oof-oof.mean(axis=-1, keepdims=True))/scale[:, None, None], 0, -1)
    group_weights = np.where(hard, 1., .25)
    group_weights /= group_weights.sum()
    def loss(w):
        s = z @ w
        if objective == 'set':
            loss_rows = logsumexp(s, axis=1)-logsumexp(np.where(y, s, -np.inf), axis=1)
            pall = np.exp(s-logsumexp(s, axis=1, keepdims=True))
            ppos = np.where(y, np.exp(s-logsumexp(np.where(y, s, -np.inf), axis=1, keepdims=True)), 0)
            gradient = np.einsum('n,nc,ncm->m', group_weights, pall-ppos, z)
        else:
            pairs = y[:, :, None] & ~y[:, None, :]
            margins = s[:, :, None]-s[:, None, :]
            denominator = pairs.sum((1, 2)).clip(1)
            loss_rows = (np.logaddexp(0, -margins)*pairs).sum((1, 2))/denominator
            from scipy.special import expit
            dz = z[:, :, None, :]-z[:, None, :, :]
            gradient = np.einsum('n,nab,nabm->m', group_weights/denominator,
                                  -expit(-margins)*pairs, dz)
        return float(loss_rows @ group_weights + l2*(w @ w)), gradient+2*l2*w
    result = minimize(loss, np.full(oof.shape[0], 1/oof.shape[0]), jac=True,
                      bounds=[(0., None)]*oof.shape[0], method='L-BFGS-B',
                      options={'maxiter': 500, 'ftol': 1e-11})
    if not result.success:
        raise RuntimeError(f'Fusion optimization failed: {result.message}')
    return result.x, scale, float(result.fun)


def optimize_accuracy(oof, y, answers):
    """Low-dimensional nonnegative coordinate search on training OOF accuracy."""
    scale = np.std(oof-oof.mean(-1, keepdims=True), axis=(1, 2)).clip(.05)
    z = np.moveaxis((oof-oof.mean(-1, keepdims=True))/scale[:, None, None], 0, -1)
    hard = np.array([len({a for a in row if a is not None}) >= 2 for row in answers])
    valid = np.array([[a is not None for a in row] for row in answers])
    rows = np.arange(len(y))
    def key(w):
        scores = z @ w
        hit = y[rows, np.where(valid, scores, -1e20).argmax(1)]
        loss = np.mean(logsumexp(scores, 1)-logsumexp(np.where(y, scores, -np.inf), 1))
        return int(hit[hard].sum()), int(hit.sum()), -float(loss)
    best = max((np.eye(oof.shape[0])[i] for i in range(oof.shape[0])), key=key)
    best_key = key(best)
    grid = (0., .025, .05, .1, .2, .35, .5, .75, 1., 1.5, 2., 3., 5.)
    for _ in range(4):
        changed = False
        for member in range(len(best)):
            for value in grid:
                proposed = best.copy()
                proposed[member] = value
                if not proposed.any():
                    continue
                score = key(proposed)
                if score > best_key:
                    best, best_key, changed = proposed, score, True
        if not changed:
            break
    return best, scale, -best_key[2]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--scan', type=Path, nargs='+', default=[Path('runs/search'), Path('runs/baseline'), Path('runs/complementary')])
    p.add_argument('--models', type=Path, nargs='+', help='Configs with matching OOF files')
    p.add_argument('--oof-dir', type=Path, default=Path('runs/oof'))
    p.add_argument('--output', type=Path, default=Path('runs/ensemble'))
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    vb, vaa = load_inputs('validation')
    _, va = extract(vb, vaa)
    vy = targets(vb, 'validation')
    scanned = discover(args.scan)
    leaderboard = []
    for path, config, scores in scanned:
        for pooling in (0., .5, 1.):
            leaderboard.append(dict(config=str(path), name=path.stem, pooling=pooling,
                                    **evaluate(scores, va, vy, pooling),
                                    asset_bytes=path.stat().st_size+(path.parent/config['weights']).stat().st_size))
    leaderboard.sort(key=lambda r: (r['hard_correct'], r['correct'], -r['asset_bytes']), reverse=True)
    (args.output/'validation-ranking.json').write_text(json.dumps(leaderboard, indent=2)+'\n')
    print(json.dumps(leaderboard[:12], indent=2), flush=True)
    if not args.models:
        return
    if len({path.stem for path in args.models}) != len(args.models):
        raise ValueError('OOF model stems must be unique; use distinct names for recipes from different directories')
    configs = [json.loads(p.read_text()) for p in args.models]
    oof = np.stack([np.load(args.oof_dir/f'{p.stem}-oof.npy', allow_pickle=False) for p in args.models])
    val = np.stack([np.load(p.with_name(p.stem+'-scores.npy'), allow_pickle=False) for p in args.models])
    bank, arrays = load_inputs('train')
    _, answers = extract(bank, arrays)
    y = targets(bank, 'train')
    hard = np.array([len({a for a in row if a is not None}) >= 2 for row in answers])
    results = []
    for objective in ('set', 'pair'):
        for l2 in (.001, .01, .1):
            w, scale, loss = optimize(oof, y, hard, l2, objective)
            scores = np.einsum('m,mnc->nc', w/scale, val)
            for pooling in (0., .5, 1.):
                record = dict(objective=objective, l2=l2, pooling=pooling,
                              coefficients=w.tolist(), scales=scale.tolist(), oof_loss=loss,
                              oof_metrics=evaluate(np.einsum('m,mnc->nc', w/scale, oof), answers, y, pooling),
                              **evaluate(scores, va, vy, pooling))
                results.append(record)
    w, scale, loss = optimize_accuracy(oof, y, answers)
    for pooling in (0., .5, 1.):
        results.append(dict(objective='oof_accuracy', l2=0., pooling=pooling,
            coefficients=w.tolist(), scales=scale.tolist(), oof_loss=loss,
            oof_metrics=evaluate(np.einsum('m,mnc->nc', w/scale, oof), answers, y, pooling),
            **evaluate(np.einsum('m,mnc->nc', w/scale, val), va, vy, pooling)))
    results.sort(key=lambda r: (r['hard_correct'], r['correct'], -r['oof_loss']), reverse=True)
    (args.output/'fusion-search.json').write_text(json.dumps(dict(models=[str(p) for p in args.models], results=results), indent=2)+'\n')
    best = results[0]
    print(json.dumps(dict(best_fusion=best), indent=2))
    members = []
    for path, config, weight, scale in zip(args.models, configs, best['coefficients'], best['scales']):
        if weight < 1e-6:
            continue
        member = dict(kind=config.get('kind', 'mlp'), coefficient=weight, scale=scale)
        prefix = path.parent.name+'-'+path.stem
        exported_weights = prefix+'.npz'
        if member['kind'] in ('mlp', 'context_mlp', 'attention_mlp'):
            member.update(mode=config['mode'], weights=exported_weights)
        else:
            member['config'] = prefix+'.json'
            exported_config = dict(config, weights=exported_weights)
            (args.output/member['config']).write_text(json.dumps(exported_config, separators=(',', ':'))+'\n')
        shutil.copy2(path.parent/config['weights'], args.output/exported_weights)
        members.append(member)
    (args.output/'config.json').write_text(json.dumps(dict(members=members, pooling=best['pooling'],
        selection='Nonnegative weights fit on training OOF; recipe selected on validation',
        validation_metrics={k:best[k] for k in ('correct','n','accuracy','hard_correct','hard_n','hard_accuracy')}), indent=2)+'\n')


if __name__ == '__main__':
    main()
