"""Train-only fitting and validation-only search. Never loads test references."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import time

# Set before importing numerical libraries; experiments run sequentially.
for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
    os.environ[key] = '4'
import numpy as np
from common import DATA, load_inputs, parse_answer, read_jsonl
from features import extract, matrix, select


def labels(bank, split):
    if split not in ('train', 'validation'):
        raise ValueError('Development only permits train/validation references')
    refs = read_jsonl(DATA/f'gsm8k_{split}.jsonl')
    assert [r['id'] for r in refs] == [r['id'] for r in bank]
    return np.asarray([[parse_answer(c['text']) is not None and
                        parse_answer(c['text']) == parse_answer(ref['answer'])
                        for c in row['candidates']] for row,ref in zip(bank,refs)])


def metrics(choices, y, hard):
    hit = y[np.arange(len(y)), choices]
    return {'accuracy': float(100*hit.mean()), 'correct': int(hit.sum()),
            'n': len(y), 'hard_accuracy': float(100*hit[hard].mean()),
            'hard_correct': int(hit[hard].sum()), 'hard_n': int(hard.sum())}


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, default=Path('runs/development'))
    p.add_argument('--phase', choices=['linear', 'neural', 'all'], default='all')
    args = p.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    bank, arrays = load_inputs('train')
    vbank, varrays = load_inputs('validation')
    f, answers = extract(bank, arrays)
    vf, va = extract(vbank, varrays)
    y, vy = labels(bank,'train'), labels(vbank,'validation')
    hard = np.array([len(set(x for x in a if x is not None)) >= 2 for a in va])
    records = []
    log = out/'experiments.jsonl'
    if log.exists():
        records = [json.loads(x) for x in log.read_text().splitlines()]
    def record(name, scores, metadata, weights=None, mode=None):
        best = None
        for pooling in (0., .5, 1.):
            m = metrics(select(scores, va, pooling), vy, hard)
            entry = dict(name=name, pooling=pooling, **m, **metadata)
            records.append(entry)
            with log.open('a') as file:
                file.write(json.dumps(entry)+'\n')
            if best is None or (m['hard_accuracy'],m['accuracy']) > (best['hard_accuracy'],best['accuracy']):
                best = entry
        np.save(out/f'{name}-scores.npy', scores)
        if weights is not None:
            np.savez(out/f'{name}.npz', **weights)
            (out/f'{name}.json').write_text(json.dumps({'mode':mode, 'weights':f'{name}.npz',
                'pooling':best['pooling'], 'name':name, **metadata}, indent=2))
        print(json.dumps(best), flush=True)
    if args.phase in ('linear','all'):
        from sklearn.linear_model import LogisticRegression
        from sklearn.preprocessing import StandardScaler
        from threadpoolctl import threadpool_limits
        with threadpool_limits(limits=4):
            record('first', np.tile([1.,0.,0.,0.],(len(vy),1)), {'kind':'baseline'})
            record('majority', vf['basic'][:,:,1], {'kind':'baseline'})
            for mode in ('style','embedding','combined'):
                x, vx = matrix(f, mode), matrix(vf, mode)
                scaler = StandardScaler().fit(x.reshape(-1,x.shape[-1]))
                z = scaler.transform(x.reshape(-1,x.shape[-1])).astype('float32')
                vz = scaler.transform(vx.reshape(-1,x.shape[-1])).astype('float32')
                for c in (.001,.01,.1,1.):
                    tick = time.perf_counter()
                    model = LogisticRegression(C=c, max_iter=600, solver='lbfgs').fit(z,y.ravel())
                    record(f'linear-{mode}-{c}', model.decision_function(vz).reshape(-1,4),
                           {'kind':'linear','C':c,'fit_seconds':time.perf_counter()-tick},
                           {'mean':scaler.mean_.astype('float32'),'scale':scaler.scale_.astype('float32'),
                            'w0':model.coef_.T.astype('float32'),'b0':model.intercept_.astype('float32')}, mode)
    if args.phase in ('neural','all'):
        import torch
        from torch import nn
        torch.set_num_threads(4)
        torch.set_num_interop_threads(1)
        # Each model is selected only at predeclared epoch intervals on validation.
        recipes = [('embedding',128,'bce',.01), ('combined',128,'bce',.01),
                   ('combined',128,'set',.01), ('combined',256,'set',.03)]
        for mode,width,objective,decay in recipes:
            x, vx = matrix(f,mode), matrix(vf,mode)
            mean = x.mean(axis=(0,1)); scale = x.std(axis=(0,1)).clip(.01)
            z = torch.from_numpy((x-mean)/scale)
            vz = torch.from_numpy((vx-mean)/scale)
            yt = torch.from_numpy(y.astype('float32'))
            for seed in (17,29,43):
                torch.manual_seed(seed)
                model = nn.Sequential(nn.Linear(x.shape[-1],width),nn.ReLU(),nn.Dropout(.2),
                                      nn.Linear(width,32),nn.ReLU(),nn.Linear(32,1))
                optimizer = torch.optim.AdamW(model.parameters(), lr=.0006,weight_decay=decay)
                tick=time.perf_counter(); best_key=(-1.,-1.); best=None
                for epoch in range(1,41):
                    model.train()
                    for idx in torch.randperm(len(y)).split(128):
                        s=model(z[idx]).squeeze(-1)
                        if objective == 'bce':
                            loss=nn.functional.binary_cross_entropy_with_logits(s,yt[idx])
                        else:
                            positive=s.masked_fill(~yt[idx].bool(),float('-inf'))
                            loss=(torch.logsumexp(s,dim=1)-torch.logsumexp(positive,dim=1)).mean()
                        optimizer.zero_grad(); loss.backward(); optimizer.step()
                    if epoch%5 == 0:
                        model.eval()
                        with torch.no_grad(): scores=model(vz).squeeze(-1).numpy()
                        m=metrics(select(scores,va),vy,hard)
                        key=(m['hard_accuracy'],m['accuracy'])
                        if key>best_key:
                            best_key=key
                            weights={'mean':mean,'scale':scale}
                            for k,layer in enumerate([model[0],model[3],model[5]]):
                                weights[f'w{k}']=layer.weight.detach().numpy().T.copy()
                                weights[f'b{k}']=layer.bias.detach().numpy().copy()
                            best=(scores.copy(),weights,epoch)
                        with (out/'epochs.jsonl').open('a') as file:
                            file.write(json.dumps(dict(mode=mode,width=width,objective=objective,seed=seed,epoch=epoch,**m))+'\n')
                scores,weights,epoch=best
                record(f'mlp-{mode}-{width}-{objective}-{seed}',scores,
                       dict(kind='mlp',seed=seed,width=width,objective=objective,weight_decay=decay,
                            epoch=epoch,fit_seconds=time.perf_counter()-tick),weights,mode)
    (out/'environment.json').write_text(json.dumps({'python':platform.python_version(),
        'platform':platform.platform(),'selection':'hard validation accuracy; overall breaks ties',
        'test_evaluated':False},indent=2))


if __name__ == '__main__': main()
