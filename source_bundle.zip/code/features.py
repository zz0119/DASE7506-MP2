"""Reference-free, within-question features; no IDs or corpus state."""
from collections import Counter
from fractions import Fraction
import re
import numpy as np
from common import parse_answer


def extract(bank, arrays):
    e = np.asarray(arrays['embeddings'], dtype=np.float32)
    norms = np.linalg.norm(e, axis=-1, keepdims=True)
    u = e / np.maximum(norms, 1e-8)
    similarities = u @ u.transpose(0, 2, 1)
    answers, rows = [], []
    for q, row in enumerate(bank):
        texts = [c['text'] for c in row['candidates']]
        a = [parse_answer(t) for t in texts]
        answers.append(a)
        counts = Counter(x for x in a if x is not None)
        lengths = [len(t) for t in texts]
        qnums = set(re.findall(r'\d+(?:\.\d+)?', row['question']))
        group = []
        for j, (t, answer) in enumerate(zip(texts, a)):
            nums = re.findall(r'\d+(?:\.\d+)?', t)
            value = float(Fraction(answer)) if answer is not None else 0.
            value = np.clip(value, -1e20, 1e20)
            peers = [k for k in range(4) if k != j]
            same = [k for k in peers if answer is not None and a[k] == answer]
            group.append([
                answer is not None, counts.get(answer, 0), len(counts),
                np.log1p(len(t)), len(t)/max(1, np.mean(lengths)),
                np.log1p(len(t.split())), t.count('\n'), t.count('='),
                t.count('\\boxed'), t.count('####'), t.count('**'),
                t.count('\\frac'), t.count('\\times'), t.count('\\text'),
                len(nums), len(set(nums)),
                len(qnums.intersection(nums))/max(1, len(qnums)),
                np.sign(value)*np.log1p(abs(value)), value == int(value), value < 0,
                float(norms[q,j,0]), float(similarities[q,j,peers].mean()),
                float(similarities[q,j,peers].max()),
                float(similarities[q,j,same].mean()) if same else 0.,
                *[t.lower().count(word) for word in ('however', 'wait', 'therefore', 'check', 'approximately', 'round')]
            ])
        rows.append(group)
    basic = np.asarray(rows, dtype=np.float32)
    return {'embedding': e, 'relative': e-e.mean(axis=1, keepdims=True),
            'basic': basic, 'basic_relative': basic-basic.mean(axis=1, keepdims=True)}, answers


def matrix(features, mode):
    keys = {'embedding': ['embedding'], 'style': ['basic'],
            'combined': ['embedding', 'relative', 'basic', 'basic_relative']}[mode]
    return np.concatenate([features[k] for k in keys], axis=-1)


def select(scores, answers, pooling=0.):
    result = []
    for s, a in zip(scores, answers):
        s = np.asarray(s, dtype=np.float64).copy()
        valid = np.array([x is not None for x in a])
        if valid.any():
            # Invalid answers can never receive a point from the fixed scorer.
            s[~valid] = -1e20
        if pooling:
            original = s.copy()
            for j, answer in enumerate(a):
                if answer is not None:
                    group = original[[x == answer for x in a]]
                    maximum = group.max()
                    group_score = maximum + np.log(np.exp(group-maximum).sum())
                    s[j] = (1-pooling)*original[j] + pooling*group_score
        result.append(int(s.argmax()))
    return result
