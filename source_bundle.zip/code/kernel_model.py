"""Train-only random Fourier RBF verifier; frozen inference requires only NumPy."""
import argparse
import json
from pathlib import Path
import time

import numpy as np

import features as baseline


def _inputs(features, mode, numeric=True):
    x = baseline.matrix(features, mode)
    extra = np.concatenate((features['basic'], features['basic_relative']), -1) if numeric else None
    return x, extra


def _basis(x, numeric, weights):
    shape = x.shape[:2]
    z = (x.reshape(-1, x.shape[-1])-weights['mean'])/weights['scale']
    phi = np.cos(z @ weights['projection']+weights['phase'])
    phi *= np.float32(np.sqrt(2/weights['projection'].shape[-1]))
    if numeric is not None:
        extra = (numeric.reshape(-1, numeric.shape[-1])-weights['numeric_mean'])/weights['numeric_scale']
        phi = np.concatenate((phi, extra), -1)
    return phi, shape


def numpy_scores(x, numeric, weights):
    phi, shape = _basis(x, numeric, weights)
    return (phi @ weights['coefficient']+weights['intercept']).reshape(shape)


def score(bank, arrays, config_path, features=None):
    """Return [N,4] scores without labels, IDs, stored examples or sklearn imports."""
    if not bank:
        return np.empty((0, 4), dtype=np.float32)
    path = Path(config_path)
    config = json.loads(path.read_text())
    weights_path = (path.parent/config['weights']).resolve()
    if not weights_path.is_relative_to(path.parent.resolve()):
        raise ValueError('Kernel weights must be inside their configuration directory')
    if features is None:
        features, _ = baseline.extract(bank, arrays)
    x, numeric = _inputs(features, config['mode'], config.get('numeric', True))
    with np.load(weights_path, allow_pickle=False) as weights:
        return numpy_scores(x, numeric, weights)


def projection(x, numeric, recipe, seed):
    """All fitted preprocessing statistics use the supplied training rows only."""
    flat = x.reshape(-1, x.shape[-1])
    mean = flat.mean(0, dtype=np.float64).astype(np.float32)
    scale = flat.std(0, dtype=np.float64).clip(.03).astype(np.float32)
    rng = np.random.default_rng(seed)
    width = recipe['m']
    weights = dict(mean=mean, scale=scale,
        projection=(rng.standard_normal((x.shape[-1], width))*np.sqrt(2*recipe['gamma']/x.shape[-1])).astype(np.float32),
        phase=rng.uniform(0, 2*np.pi, width).astype(np.float32))
    if numeric is not None:
        flat_numeric = numeric.reshape(-1, numeric.shape[-1])
        weights['numeric_mean'] = flat_numeric.mean(0, dtype=np.float64).astype(np.float32)
        weights['numeric_scale'] = flat_numeric.std(0, dtype=np.float64).clip(.03).astype(np.float32)
    return weights


def fit_linear(phi, y, weights, C):
    from sklearn.linear_model import LogisticRegression
    model = LogisticRegression(C=C, max_iter=500, tol=1e-5, solver='lbfgs')
    model.fit(phi, y.reshape(-1))
    exported = {key: value.copy() for key, value in weights.items()}
    exported['coefficient'] = model.coef_[0].astype(np.float32)
    exported['intercept'] = model.intercept_.astype(np.float32)
    expected = model.decision_function(phi)
    actual = phi @ exported['coefficient']+exported['intercept']
    if not np.allclose(actual, expected, atol=2e-4, rtol=2e-4):
        raise ValueError('NumPy logistic export does not reproduce sklearn scores')
    return exported, model.n_iter_.tolist()


def _name(recipe, seed):
    return f"rff-{recipe['mode']}-{recipe['m']}-g{recipe['gamma']:g}-c{recipe['C']:g}-{seed}"


def _save(output, recipe, seed, weights, scores, answers, y, fit_seconds, iterations):
    from ensemble import evaluate
    name = _name(recipe, seed)
    output.mkdir(parents=True, exist_ok=True)
    weights_path = output/f'{name}.npz'
    np.savez(weights_path, **weights)
    np.save(output/f'{name}-scores.npy', scores)
    record = dict(name=name, kind='rff', mode=recipe['mode'], numeric=True,
        m=recipe['m'], gamma=recipe['gamma'], C=recipe['C'], recipe=recipe,
        seed=seed, weights=weights_path.name, fit_seconds=fit_seconds,
        iterations=iterations, fit_scope='supplied train only', pooling=0.,
        array_asset_bytes=sum(value.nbytes for value in weights.values()),
        **evaluate(scores, answers, y))
    config_path = output/f'{name}.json'
    record['pooling_metrics'] = [dict(pooling=p, **evaluate(scores, answers, y, p)) for p in (.5, 1.)]
    record['asset_bytes'] = 0
    for _ in range(3):
        config_path.write_text(json.dumps(record, indent=2)+'\n')
        record['asset_bytes'] = weights_path.stat().st_size+config_path.stat().st_size
    config_path.write_text(json.dumps(record, indent=2)+'\n')
    if weights_path.stat().st_size+config_path.stat().st_size > 16*2**20:
        raise ValueError('RFF asset bundle exceeds 16 MiB')
    with (output/'experiments.jsonl').open('a') as out:
        out.write(json.dumps(record)+'\n')
    print(json.dumps(record), flush=True)
    return config_path, record


def oof(config_path, output, bank, features, answers, y):
    from sklearn.model_selection import StratifiedKFold
    from ensemble import evaluate
    config = json.loads(Path(config_path).read_text())
    recipe, seed = config['recipe'], config['seed']
    x, numeric = _inputs(features, recipe['mode'])
    hard = np.array([len({a for a in row if a is not None}) >= 2 for row in answers])
    stratify = hard.astype(int)*5+y.sum(1)
    scores = np.zeros(y.shape, np.float32)
    records = []
    for fold, (ti, hi) in enumerate(StratifiedKFold(3, shuffle=True, random_state=17).split(x, stratify)):
        tick = time.perf_counter()
        weights = projection(x[ti], numeric[ti], recipe, seed)
        phi, _ = _basis(x[ti], numeric[ti], weights)
        weights, iterations = fit_linear(phi, y[ti], weights, recipe['C'])
        scores[hi] = numpy_scores(x[hi], numeric[hi], weights)
        record = dict(fold=fold, train_questions=len(ti), heldout_questions=len(hi),
                      fit_seconds=time.perf_counter()-tick, iterations=iterations,
                      **evaluate(scores[hi], [answers[i] for i in hi], y[hi]))
        records.append(record)
        print(json.dumps(dict(name=config['name'], **record)), flush=True)
    output.mkdir(parents=True, exist_ok=True)
    np.save(output/f"{config['name']}-oof.npy", scores)
    (output/f"{config['name']}-oof.json").write_text(json.dumps(dict(name=config['name'],
        folds=records, fit_scope='train only; question-grouped three-fold OOF',
        seed=17, metrics=evaluate(scores, answers, y)), indent=2)+'\n')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=Path('runs/kernel'))
    p.add_argument('--oof-config', type=Path)
    p.add_argument('--seed', type=int, default=17)
    args = p.parse_args()
    from common import load_inputs
    from ensemble import targets
    from threadpoolctl import threadpool_limits
    with threadpool_limits(limits=2):
        bank, arrays = load_inputs('train')
        features, answers = baseline.extract(bank, arrays)
        y = targets(bank, 'train')
        if args.oof_config:
            oof(args.oof_config, args.output, bank, features, answers, y)
            return
        vb, varrays = load_inputs('validation')
        vf, va = baseline.extract(vb, varrays)
        vy = targets(vb, 'validation')
        records = []
        for mode in ('embedding', 'combined'):
            x, numeric = _inputs(features, mode)
            vx, vnumeric = _inputs(vf, mode)
            for gamma in (.25, 1., 4.):
                recipe = dict(mode=mode, m=1024, gamma=gamma)
                tick = time.perf_counter()
                weights = projection(x, numeric, recipe, args.seed)
                phi, _ = _basis(x, numeric, weights)
                vphi, shape = _basis(vx, vnumeric, weights)
                project_seconds = time.perf_counter()-tick
                for C in (.1, 1., 10.):
                    recipe = dict(recipe, C=C)
                    name = _name(recipe, args.seed)
                    config_path = args.output/f'{name}.json'
                    if config_path.exists():
                        records.append((config_path, json.loads(config_path.read_text())))
                        continue
                    tick = time.perf_counter()
                    fitted, iterations = fit_linear(phi, y, weights, C)
                    scores = (vphi @ fitted['coefficient']+fitted['intercept']).reshape(shape)
                    records.append(_save(args.output, recipe, args.seed, fitted, scores, va, vy,
                                          project_seconds+time.perf_counter()-tick, iterations))
        records.sort(key=lambda item: (item[1]['hard_correct'], item[1]['correct'], -item[1]['asset_bytes']), reverse=True)
        best_path, best = records[0]
        print(json.dumps(dict(best_config=str(best_path), best=best)), flush=True)
        if best['hard_accuracy'] >= 80:
            oof(best_path, args.output, bank, features, answers, y)


if __name__ == '__main__':
    main()
