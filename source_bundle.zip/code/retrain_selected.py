"""Reproduce selected neural weights at fixed epochs and copy frozen fusion.

Manifest fields:
  ensemble_config: the final inference configuration, including fixed fusion.
  members: [{source_config, recipe, seed, epoch, name, legacy, output_weights?}]

source_config is relative to code/. output_weights defaults to the source
configuration's weights filename. No model/epoch/fusion selection is performed.
Validation references are never loaded: dummy labels satisfy the fixed-epoch
trainer's reporting interface and are never used to select or update weights.
"""
import argparse
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import time

for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS'):
    os.environ[_key] = os.environ.get('MP2_TRAIN_THREADS', '2')

import numpy as np

# train initializes torch's interop pool once; do not initialize it again here.
import train
import advanced_features as af
import baseline_oof
from common import load_inputs
from features import select
from submission import mlp_scores


CODE = Path(__file__).resolve().parent
NEURAL_KINDS = frozenset(('mlp', 'context_mlp', 'attention_mlp'))


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def output_path(root, relative):
    if not isinstance(relative, str) or Path(relative).is_absolute():
        raise ValueError('Output weight paths must be relative strings')
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or path.suffix != '.npz':
        raise ValueError(f'Invalid output weight path: {relative}')
    return path


def neural_scores(x, answers, weights, kind):
    if kind == 'attention_mlp':
        import attention_model
        return attention_model.numpy_scores(x, train.same_mask(answers), weights)
    if kind in ('mlp', 'context_mlp'):
        return mlp_scores(x, answers, weights, context=kind == 'context_mlp')
    raise ValueError(f'Only neural models are supported: {kind}')


def check_weights(actual, expected):
    if set(actual) != set(expected):
        raise ValueError('Reproduced weight keys differ from the selected checkpoint')
    errors, exact = {}, True
    for key in sorted(expected):
        left, right = actual[key], expected[key]
        if left.shape != right.shape or left.dtype != right.dtype:
            raise ValueError(f'Reproduced weight shape/dtype differs: {key}')
        errors[key] = float(np.max(np.abs(left-right))) if left.size else 0.
        exact = exact and np.array_equal(left, right)
        if not np.allclose(left, right, atol=2e-4, rtol=2e-4):
            raise ValueError(f'Reproduced weights differ from selected checkpoint: {key}')
    return exact, errors


def reproduce(manifest_path, output):
    manifest_path, output = Path(manifest_path).resolve(), Path(output).resolve()
    if not output.is_relative_to(CODE):
        raise ValueError('Save reproduction artifacts inside code/ to keep this project together')
    manifest = json.loads(manifest_path.read_text())
    ensemble = deepcopy(manifest['ensemble_config'])
    entries = manifest['members']
    if not entries or not ensemble.get('members'):
        raise ValueError('Manifest must specify selected models and fixed ensemble members')
    if any(member.get('kind', 'mlp') not in NEURAL_KINDS for member in ensemble['members']):
        raise ValueError('This reproducer handles neural members only; complementary models need their own refit')

    prepared, destinations = [], set()
    for entry in entries:
        source_path = Path(entry['source_config'])
        source_path = (CODE / source_path).resolve() if not source_path.is_absolute() else source_path.resolve()
        if not source_path.is_relative_to(CODE):
            raise ValueError('Source configurations must be inside code/')
        source = json.loads(source_path.read_text())
        if output == source_path.parent:
            raise ValueError('Reproduction output must not overwrite a source checkpoint directory')
        if (entry['seed'], entry['epoch']) != (source['seed'], source['epoch']):
            raise ValueError(f"Manifest seed/epoch differ from selected model: {entry['name']}")
        if not entry.get('legacy', False) and entry['recipe'] != source['recipe']:
            raise ValueError(f"Manifest recipe differs from selected model: {entry['name']}")
        kind = source.get('kind', 'mlp')
        if kind not in NEURAL_KINDS:
            raise ValueError(f'Unsupported selected model: {kind}')
        if source['mode'] not in ('combined', 'embedding', 'style') and source.get('feature_version') != af.FEATURE_VERSION:
            raise ValueError(f"Selected model feature version differs: {entry['name']}")
        destination = entry.get('output_weights', source['weights'])
        output_path(output, destination)
        if destination in destinations:
            raise ValueError(f'Duplicate output filename: {destination}')
        destinations.add(destination)
        source_weights = (source_path.parent / source['weights']).resolve()
        if not source_weights.is_relative_to(source_path.parent):
            raise ValueError('Source checkpoint weight path escapes its directory')
        prepared.append((entry, source_path, source, source_weights, destination))
    if destinations != {member['weights'] for member in ensemble['members']}:
        raise ValueError('Training manifest must cover exactly the final ensemble weight files')
    sources_by_output = {destination: source for _, _, source, _, destination in prepared}
    for member in ensemble['members']:
        source = sources_by_output[member['weights']]
        if (member.get('kind', 'mlp'), member['mode']) != (source.get('kind', 'mlp'), source['mode']):
            raise ValueError('Frozen ensemble kind/mode differ from the selected source configuration')
        coefficient, scale, offset = member.get('coefficient', 1.), member.get('scale', 1.), member.get('offset', 0.)
        if not all(np.isfinite(value) for value in (coefficient, scale, offset)) or coefficient < 0 or scale <= 0:
            raise ValueError('Frozen fusion must have finite nonnegative coefficients and positive scales')

    bank, arrays = load_inputs('train')
    vb, va_arrays = load_inputs('validation')
    features, answers = af.extract(bank, arrays)
    vfeatures, va = af.extract(vb, va_arrays)
    y = train.references(bank, 'train')
    # Fixed-epoch fitting computes reporting metrics but never branches on these labels.
    unused_validation_labels = np.zeros((len(vb), 4), dtype=bool)
    matrices = {}
    reference_scores, reproduced_scores, records = {}, {}, []
    output.mkdir(parents=True, exist_ok=True)
    start = time.perf_counter()
    for entry, source_path, source, source_weights, destination in prepared:
        tick = time.perf_counter()
        mode = source['mode']
        if mode not in matrices:
            matrices[mode] = af.matrix(features, mode), af.matrix(vfeatures, mode)
        x, vx = matrices[mode]
        if entry.get('legacy', False):
            weights = baseline_oof.fit_legacy(x, y, source, entry['seed'])
            scores = neural_scores(vx, va, weights, source.get('kind', 'mlp'))
        else:
            weights, scores, result, _ = train.fit(
                x, y, answers, vx, unused_validation_labels, va,
                entry['recipe'], entry['seed'], fixed_epoch=entry['epoch'])
            if result['epoch'] != entry['epoch']:
                raise ValueError('Reproduction failed to use the fixed selected epoch')
        with np.load(source_weights, allow_pickle=False) as archive:
            expected = {key: archive[key] for key in archive.files}
        exact, errors = check_weights(weights, expected)
        kind = source.get('kind', 'mlp')
        expected_scores = neural_scores(vx, va, expected, kind)
        if not np.allclose(scores, expected_scores, atol=2e-4, rtol=2e-4):
            raise ValueError(f"Validation export differs for selected model: {entry['name']}")
        choices_equal = select(scores, va) == select(expected_scores, va)
        if not choices_equal:
            raise ValueError(f"Reproduction changes validation choices: {entry['name']}")
        target = output_path(output, destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        np.savez(target, **weights)
        reference_scores[destination], reproduced_scores[destination] = expected_scores, scores
        records.append({'name': entry['name'], 'legacy': entry.get('legacy', False),
                        'source_config': str(source_path.relative_to(CODE)),
                        'source_config_sha256': digest(source_path), 'source_weights_sha256': digest(source_weights),
                        'output_weights': destination, 'output_weights_sha256': digest(target),
                        'seed': entry['seed'], 'epoch': entry['epoch'], 'arrays_bitwise_equal': exact,
                        'weight_max_abs_error': errors,
                        'validation_score_max_abs_error': float(np.max(np.abs(scores-expected_scores))),
                        'validation_choices_equal': choices_equal, 'seconds': time.perf_counter()-tick})
        print(json.dumps(records[-1]), flush=True)

    def fused(values):
        result = np.zeros((len(vb), 4), dtype=np.float64)
        for member in ensemble['members']:
            result += member.get('coefficient', 1.)*(values[member['weights']]-member.get('offset', 0.))/member.get('scale', 1.)
        return result

    expected, actual = fused(reference_scores), fused(reproduced_scores)
    same_choices = select(actual, va, ensemble.get('pooling', 0.)) == select(expected, va, ensemble.get('pooling', 0.))
    if not same_choices:
        raise ValueError('Fixed fusion changes validation choices after reproduction')
    (output / 'config.json').write_text(json.dumps(ensemble, indent=2)+'\n')
    record = {'manifest': str(manifest_path), 'manifest_sha256': digest(manifest_path),
              'fit_scope': 'supplied train only; fixed selected epochs; no validation references loaded',
              'fusion': 'copied from manifest without recomputing coefficients, scales or pooling',
              'members': records, 'validation_ensemble_choices_equal': same_choices,
              'validation_ensemble_score_max_abs_error': float(np.max(np.abs(actual-expected))),
              'seconds': time.perf_counter()-start, 'threads': train.torch.get_num_threads(),
              'output_config_sha256': digest(output / 'config.json')}
    report = output.parent / f'{output.name}-training-reproduction.json'
    report.write_text(json.dumps(record, indent=2)+'\n')
    return record


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, default=Path('runs/selected-training.json'))
    parser.add_argument('--output', type=Path, default=Path('runs/retrained'))
    args = parser.parse_args()
    result = reproduce(args.manifest, args.output)
    print(json.dumps({'validation_ensemble_choices_equal': result['validation_ensemble_choices_equal'],
                      'seconds': result['seconds'], 'output': str(args.output)}, indent=2))


if __name__ == '__main__':
    main()
