#!/usr/bin/env bash
set -euo pipefail

CODE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
export OMP_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 MKL_NUM_THREADS=4
export VECLIB_MAXIMUM_THREADS=4 NUMEXPR_NUM_THREADS=4 BLIS_NUM_THREADS=4
export PYTHONDONTWRITEBYTECODE=1
cd "$CODE_DIR"
if [[ ! -x "$CODE_DIR/.venv/bin/python" ]]; then
    echo 'Create code/.venv with Python 3.12 and install requirements-inference.txt first.' >&2
    exit 1
fi
exec "$CODE_DIR/.venv/bin/python" "$@"
