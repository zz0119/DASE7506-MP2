"""Offline candidate selection; inference never opens reference answers."""
import json
from pathlib import Path
import numpy as np
from features import select
from threadpoolctl import threadpool_limits


def asset_path(root, name):
    path = (root/name).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError('Checkpoint asset must be inside its bundle directory')
    return path


def mlp_scores(x, answers, weights, context=False):
    h = (x-weights['mean'])/weights['scale']
    k = 0
    while f'w{k}' in weights:
        h = h @ weights[f'w{k}'] + weights[f'b{k}']
        if f'w{k+1}' in weights:
            h = np.maximum(h, 0)
        if k == 0 and context:
            same = np.array([[[a is not None and a == b for b in row] for a in row]
                             for row in answers], dtype=np.float32)
            group = np.broadcast_to(h.mean(1, keepdims=True), h.shape)
            maximum = np.broadcast_to(h.max(1, keepdims=True), h.shape)
            same_mean = (same @ h)/np.maximum(same.sum(-1, keepdims=True), 1)
            h = np.concatenate((h, group, maximum, same_mean-h), axis=-1)
        k += 1
    return h[:, :, 0]


def predict(bank, arrays, checkpoint):
    """Return one Python integer in 0..3 per question, in bank order.

    bank: list of question dictionaries with four candidate texts each.
    arrays['embeddings']: float32 NumPy array of shape [N, 4, 1024].
    checkpoint: pathlib.Path or None, supplied through --checkpoint.
    """
    if checkpoint is None:
        raise ValueError('Supply the selected model JSON or bundle directory')
    checkpoint = Path(checkpoint)
    if checkpoint.is_dir():
        checkpoint = checkpoint/'config.json'
    config = json.loads(checkpoint.read_text())
    if not bank:
        return []
    import advanced_features as af
    features, answers = af.extract(bank, arrays)
    scores = np.zeros((len(bank),4),dtype=np.float64)
    members = config.get('members', [dict(config, coefficient=1.)])
    matrices = {}
    with threadpool_limits(limits=4):
        for member in members:
            coefficient = float(member.get('coefficient', 1.))
            if not np.isfinite(coefficient) or coefficient < 0:
                raise ValueError('Ensemble coefficients must be finite and nonnegative')
            kind = member.get('kind', 'mlp')
            if kind in ('mlp', 'context_mlp', 'attention_mlp'):
                mode = member['mode']
                if mode not in matrices:
                    matrices[mode] = af.matrix(features, mode)
                with np.load(asset_path(checkpoint.parent, member['weights']), allow_pickle=False) as w:
                    if kind == 'attention_mlp':
                        import attention_model
                        same = np.array([[[a is not None and a == b for b in row] for a in row]
                                         for row in answers], dtype=np.float32)
                        member_scores = attention_model.numpy_scores(matrices[mode], same, w)
                    else:
                        member_scores = mlp_scores(matrices[mode], answers, w, kind == 'context_mlp')
            elif kind in ('tfidf', 'hist_tree', 'text', 'tree'):
                import complementary
                config_path = (asset_path(checkpoint.parent, member['config'])
                               if 'config' in member else checkpoint)
                member_scores = complementary.score(bank, arrays,
                    config_path, features=features)
            elif kind == 'rff':
                import kernel_model
                config_path = (asset_path(checkpoint.parent, member['config'])
                               if 'config' in member else checkpoint)
                member_scores = kernel_model.score(bank, arrays, config_path, features=features)
            else:
                raise ValueError(f'Unknown model kind: {kind}')
            if member_scores.shape != scores.shape or not np.isfinite(member_scores).all():
                raise ValueError('Invalid candidate scores')
            offset, scale = member.get('offset', 0.), member.get('scale', 1.)
            if not np.isfinite(offset) or not np.isfinite(scale) or scale <= 0:
                raise ValueError('Invalid score scale')
            scores += coefficient*(member_scores-offset)/scale
    return select(scores, answers, config.get('pooling',0.))
