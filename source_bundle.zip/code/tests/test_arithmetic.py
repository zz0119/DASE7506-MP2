"""Behavioral checks for safe numeric evidence and candidate equivariance."""
from fractions import Fraction
from pathlib import Path
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import advanced_features as af
import features


class ArithmeticTests(unittest.TestCase):
    def test_exact_decimal_fraction_and_precedence(self):
        self.assertEqual(af.safe_arithmetic('0.1+0.2'), Fraction(3, 10))
        self.assertEqual(af.safe_arithmetic('-(3+5)/2'), -4)
        self.assertEqual(af.safe_arithmetic('2**3+4*5'), 28)

    def test_reject_code_and_unbounded_expressions(self):
        for expression in ('__import__("os").system("touch /tmp/mp2-unsafe")',
                           'True', 'x+1', '[1][0]', '(1).__class__',
                           '2**1000000', '10**(10**10)', '1/0',
                           '9'*100, '('*100+'1'+')'*100):
            with self.subTest(expression=expression):
                self.assertIsNone(af.safe_arithmetic(expression))

    def test_latex_fractions_percent_and_commas(self):
        examples = {r'\frac{10+15+5}{2}': 15,
                    r'\frac{1}{\frac{2}{3}}': Fraction(3, 2),
                    r'25\% \times 160': 40,
                    '1,200.5 + 1,25': Fraction('1201.75'),
                    '1,234,567 - 234,567': 1000000,
                    '8 \u00d7 3 \u2212 4': 20}
        for expression, expected in examples.items():
            with self.subTest(expression=expression):
                self.assertEqual(af.safe_arithmetic(af.normalize_math(expression)), expected)

    def test_equation_chain_skips_symbols_and_finds_error(self):
        text = af.normalize_math(r'Price = \frac{40}{0.25} = 160 = 120')
        count, checked = af.equation_evidence(text)
        self.assertEqual(count, 3)
        self.assertEqual(len(checked), 2)
        self.assertEqual(checked[0][2], 0)
        self.assertGreater(checked[1][2], 0.1)
        self.assertEqual(af.equation_evidence('x = y+1')[1], [])

    def test_equations_do_not_truncate_variables_prose_or_units(self):
        for text in ('3x + 12 = 30', 'x + 108 = 160', '25 = 2x + 6',
                     '24 = 6 C', 'Half of 28 = 14 students',
                     r'6 \text{ hours} = 360 \text{ minutes}',
                     '90% of 2000 = 1800', '$2.50 = 250 cents'):
            with self.subTest(text=text):
                self.assertEqual(af.equation_evidence(af.normalize_math(text))[1], [])
        for text in ('- $20 * 30 = $600', 'Cost: 12*3 = 36 dollars',
                     r'6 \text{ hours} = 6 \times 60 = 360 \text{ minutes}',
                     r'\frac{8}{25} \times 100 = 32\%'):
            with self.subTest(text=text):
                _, checked = af.equation_evidence(af.normalize_math(text))
                self.assertEqual(len(checked), 1)
                self.assertEqual(checked[0][2], 0)

    @staticmethod
    def fixture():
        bank = [{'id': 'unused', 'question': 'Three bags cost $12 each. What is the total?',
                 'candidates': [{'index': j, 'text': text} for j, text in enumerate((
                     '3*12 = 36\n#### 36', '12+3 = 15\n#### 15',
                     r'\frac{72}{2} = 36'+'\n#### 36', 'No final answer.'))]}]
        arrays = {'embeddings': np.random.default_rng(9).normal(size=(1, 4, 1024)).astype(np.float32)}
        return bank, arrays

    def test_baseline_compatibility_and_dimensions(self):
        bank, arrays = self.fixture()
        actual, answers = af.extract(bank, arrays)
        expected, baseline_answers = features.extract(bank, arrays)
        self.assertEqual(answers, baseline_answers)
        for mode in ('embedding', 'style', 'combined'):
            np.testing.assert_array_equal(af.matrix(actual, mode), features.matrix(expected, mode))
        self.assertEqual(af.dimensions(actual)['advanced'], 2108+2*len(af.FEATURE_NAMES))
        self.assertTrue(np.isfinite(af.matrix(actual, 'context')).all())

    def test_equivariance_and_ids_unused(self):
        bank, arrays = self.fixture()
        expected, answers = af.extract(bank, arrays)
        permutation = np.array([3, 1, 0, 2])
        moved = [{'id': 'different', 'question': bank[0]['question'],
                  'candidates': [bank[0]['candidates'][i] for i in permutation]}]
        actual, moved_answers = af.extract(moved, {'embeddings': arrays['embeddings'][:, permutation]})
        self.assertEqual(moved_answers[0], [answers[0][i] for i in permutation])
        for mode in ('advanced', 'context'):
            np.testing.assert_allclose(af.matrix(actual, mode), af.matrix(expected, mode)[:, permutation], atol=1e-6)

    def test_empty_and_invalid_answers(self):
        actual, answers = af.extract([], {'embeddings': np.empty((0, 4, 1024), dtype=np.float32)})
        self.assertEqual(answers, [])
        self.assertEqual(af.matrix(actual, 'advanced').shape, (0, 4, 2108+2*len(af.FEATURE_NAMES)))
        bank, arrays = self.fixture()
        for candidate in bank[0]['candidates']:
            candidate['text'] = 'Words without a numeric answer.'
        actual, answers = af.extract(bank, arrays)
        self.assertEqual(answers, [[None]*4])
        self.assertTrue(np.isfinite(af.matrix(actual, 'context')).all())

    def test_final_box_does_not_count_as_working(self):
        bank, arrays = self.fixture()
        bank[0]['candidates'][0]['text'] = r'12 + 3 = 15. Final answer: \boxed{37}'
        actual, _ = af.extract(bank, arrays)
        column = af.FEATURE_NAMES.index('answer_in_working')
        self.assertEqual(actual['advanced'][0, 0, column], 0)


if __name__ == '__main__':
    unittest.main()
