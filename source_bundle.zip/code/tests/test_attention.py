"""Export fidelity, numerical stability and candidate permutation behavior."""
from pathlib import Path
import subprocess
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import attention_model as am


class AttentionTests(unittest.TestCase):
    @staticmethod
    def fixture(width=128):
        import torch
        torch.manual_seed(11)
        generator = np.random.default_rng(11)
        x = generator.normal(size=(7, 4, 23)).astype(np.float32)
        same = np.tile(np.eye(4, dtype=np.float32), (7, 1, 1))
        same[:, 0, 2] = same[:, 2, 0] = 1
        same[1, 3] = 0  # An unparsable answer has no same-answer membership.
        mean = generator.normal(size=23).astype(np.float32)
        scale = generator.uniform(.1, 3, size=23).astype(np.float32)
        model = am.AttentionRanker(23, width, .25).eval()
        return model, x, same, mean, scale

    def test_module_import_keeps_torch_unloaded(self):
        result = subprocess.run([sys.executable, '-c',
            'import sys; import attention_model; assert "torch" not in sys.modules'],
            cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_export_matches_torch_for_both_widths(self):
        import torch
        for width in (128, 256):
            with self.subTest(width=width):
                model, x, same, mean, scale = self.fixture(width)
                with torch.no_grad():
                    expected = model(torch.from_numpy((x-mean)/scale), torch.from_numpy(same)).numpy()
                weights = am.export(model, mean, scale)
                actual = am.numpy_scores(x, same, weights)
                np.testing.assert_allclose(actual, expected, atol=2e-5, rtol=2e-5)
                np.testing.assert_array_equal(actual.argmax(-1), expected.argmax(-1))

    def test_candidate_permutation_equivariance(self):
        model, x, same, mean, scale = self.fixture()
        weights = am.export(model, mean, scale)
        expected = am.numpy_scores(x, same, weights)
        permutation = [3, 1, 0, 2]
        actual = am.numpy_scores(x[:, permutation], same[:, permutation][:, :, permutation], weights)
        np.testing.assert_allclose(actual, expected[:, permutation], atol=1e-6, rtol=2e-5)

    def test_stable_softmax_zero_mask_and_empty_input(self):
        model, x, same, mean, scale = self.fixture()
        weights = am.export(model, mean, scale)
        weights['query_weight'] *= 1000
        weights['key_weight'] *= 1000
        scores = am.numpy_scores(x, np.zeros_like(same), weights)
        self.assertTrue(np.isfinite(scores).all())
        self.assertEqual(am.numpy_scores(x[:0], same[:0], weights).shape, (0, 4))

    def test_pair_bce_gradients_reach_attention(self):
        import torch
        model, x, same, mean, scale = self.fixture()
        model.train()
        scores = model(torch.from_numpy((x-mean)/scale), torch.from_numpy(same))
        target = torch.tensor([[1., 0., 1., 0.]]).expand_as(scores)
        pairs = target.bool().unsqueeze(2) & ~target.bool().unsqueeze(1)
        loss = torch.nn.functional.binary_cross_entropy_with_logits(scores, target)
        loss += (torch.nn.functional.softplus(-(scores.unsqueeze(2)-scores.unsqueeze(1)))*pairs).sum()/pairs.sum()
        loss.backward()
        for layer in (model.first, model.query, model.key, model.value, model.attention_out):
            self.assertTrue(torch.isfinite(layer.weight.grad).all())
            self.assertGreater(layer.weight.grad.abs().sum().item(), 0)


if __name__ == '__main__':
    unittest.main()
