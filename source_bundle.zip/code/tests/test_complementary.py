"""Check portable inference against the training-library implementations."""
import unittest
from pathlib import Path
import tempfile

import numpy as np

from complementary import export_trees, score_text, score_trees, score_member, structural


class ComplementaryExportTests(unittest.TestCase):
    def test_nested_asset_cannot_escape_bundle(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            assets = root / 'bundle'
            assets.mkdir()
            np.savez(root / 'outside.npz', baseline=np.array([0.]))
            with self.assertRaisesRegex(ValueError, 'inside the asset directory'):
                score_member([{}], {}, {}, None,
                             dict(kind='tree', weights='../outside.npz'), assets)

    def test_advanced_structure_accepts_cached_superset(self):
        import advanced_features
        dim = len(advanced_features.ADVANCED_NAMES) if hasattr(advanced_features, 'ADVANCED_NAMES') else 60
        f = dict(basic=np.zeros((1, 4, 30), np.float32),
                 basic_relative=np.zeros((1, 4, 30), np.float32),
                 advanced=np.zeros((1, 4, dim), np.float32),
                 advanced_relative=np.zeros((1, 4, dim), np.float32))
        expected = np.concatenate([f['basic'], f['basic_relative'],
                                   advanced_features.matrix(f, 'arithmetic')], axis=-1)
        np.testing.assert_array_equal(structural([{}], {}, f, 'advanced'), expected)

    def test_tfidf_export_matches_sparse_transform(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        docs = ['A train travels 20 miles, then 20 more miles.',
                'Café receipts: 12 items for $3.50 each.',
                'The total is 12/3 = 4; final answer 4.', 'Unknown words nowhere']
        vectorizer = TfidfVectorizer(ngram_range=(1, 2), sublinear_tf=True,
                                     dtype=np.float32).fit(docs[:3])
        coef = np.random.default_rng(7).normal(size=len(vectorizer.vocabulary_)).astype(np.float32)
        config = dict(vocabulary=vectorizer.vocabulary_, ngram_max=2, sublinear_tf=True)
        weights = dict(idf=vectorizer.idf_, text_weights=coef,
                       intercept=np.asarray([.3], dtype=np.float32))
        expected = vectorizer.transform(docs) @ coef + .3
        np.testing.assert_allclose(score_text(docs, config, weights), expected,
                                   atol=1e-6, rtol=1e-6)

    def test_tree_export_matches_raw_logits_and_subbatches(self):
        from sklearn.ensemble import HistGradientBoostingClassifier
        x = np.random.default_rng(19).normal(size=(300, 5)).astype(np.float32)
        y = x[:, 0] + x[:, 1] > 0
        x[::7, 0] = np.nan
        model = HistGradientBoostingClassifier(max_iter=8, max_leaf_nodes=7,
            early_stopping=False, random_state=19).fit(x, y)
        weights = export_trees(model)
        np.testing.assert_allclose(score_trees(x, weights), model.decision_function(x),
                                   atol=1e-6, rtol=1e-6)
        np.testing.assert_array_equal(score_trees(x, weights), np.concatenate(
            [score_trees(part, weights) for part in np.array_split(x, 3)]))


if __name__ == '__main__':
    unittest.main()
