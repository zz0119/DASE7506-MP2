"""Behavioral prediction contract, using validation inputs without references.

Run from code/: MP2_CHECKPOINT=runs/final python -m unittest discover -s tests -v
"""
from copy import deepcopy
import builtins
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

import numpy as np

CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))
from common import load_inputs, parse_answer
from submission import predict
from verify import assert_frozen, inference_files, resources, sha256, snapshot


class PredictionContract(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.checkpoint = Path(os.environ.get(
            'MP2_CHECKPOINT', str(CODE / 'runs/baseline/mlp-combined-128-bce-17.json'))).resolve()
        if not cls.checkpoint.exists():
            raise unittest.SkipTest(f'Checkpoint unavailable: {cls.checkpoint}')
        bank, arrays = load_inputs('validation')
        cls.bank = bank[:23]
        cls.arrays = {key: value[:23].copy() for key, value in arrays.items()}

    def guarded_predict(self, bank, arrays):
        """Inference must use passed inputs; no source data/reference access."""
        data_root = (CODE / 'data').resolve()

        def guard(original):
            def checked(file, *args, **kwargs):
                if isinstance(file, (str, bytes, os.PathLike)):
                    path = Path(os.fsdecode(file)).resolve()
                    if path.is_relative_to(data_root):
                        raise AssertionError(f'Inference attempted to open supplied data: {path}')
                    if path.name in ('gsm8k_train.jsonl', 'gsm8k_validation.jsonl', 'gsm8k_test.jsonl'):
                        raise AssertionError(f'Inference attempted to open a bank or reference file: {path}')
                return original(file, *args, **kwargs)
            return checked

        with patch.object(builtins, 'open', guard(builtins.open)), patch.object(io, 'open', guard(io.open)):
            result = predict(bank, arrays, self.checkpoint)
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), len(bank))
        self.assertTrue(all(type(index) is int and 0 <= index < 4 for index in result))
        return result

    def test_varied_bank_sizes(self):
        for n in (1, 2, 7, 23):
            with self.subTest(n=n):
                self.guarded_predict(deepcopy(self.bank[:n]),
                                     {key: value[:n].copy() for key, value in self.arrays.items()})

    def test_deterministic_and_nonmutating(self):
        bank = deepcopy(self.bank)
        arrays = {key: value.copy() for key, value in self.arrays.items()}
        expected = self.guarded_predict(bank, arrays)
        self.assertEqual(expected, self.guarded_predict(bank, arrays))
        self.assertEqual(bank, self.bank)
        for key in arrays:
            np.testing.assert_array_equal(arrays[key], self.arrays[key])

    def test_bank_order_and_ids_are_only_alignment(self):
        expected = self.guarded_predict(self.bank, self.arrays)
        order = np.random.default_rng(7506).permutation(len(self.bank))
        bank = [deepcopy(self.bank[index]) for index in order]
        for index, row in enumerate(bank):
            row['id'] = f'unseen-contract-id-{index}'
        result = self.guarded_predict(bank, {key: value[order].copy() for key, value in self.arrays.items()})
        self.assertEqual(result, [expected[index] for index in order])

    def test_candidate_permutation_preserves_selected_answer(self):
        expected = self.guarded_predict(self.bank, self.arrays)
        rng = np.random.default_rng(16)
        permutations = [rng.permutation(4) for _ in self.bank]
        bank = deepcopy(self.bank)
        arrays = {key: value.copy() for key, value in self.arrays.items()}
        for q, permutation in enumerate(permutations):
            bank[q]['candidates'] = [deepcopy(self.bank[q]['candidates'][index]) for index in permutation]
            for index, candidate in enumerate(bank[q]['candidates']):
                candidate['index'] = index
            for key in arrays:
                arrays[key][q] = self.arrays[key][q, permutation]
        result = self.guarded_predict(bank, arrays)
        # Identical answer groups may tie, so compare the official parsed answer.
        for q, index in enumerate(result):
            self.assertEqual(parse_answer(bank[q]['candidates'][index]['text']),
                             parse_answer(self.bank[q]['candidates'][expected[q]]['text']))

    def test_empty_bank(self):
        self.assertEqual(self.guarded_predict([], {key: value[:0].copy() for key, value in self.arrays.items()}), [])

    def test_all_assets_are_contained_and_under_limit(self):
        root, paths = inference_files(self.checkpoint)
        self.assertTrue(paths)
        self.assertTrue(all(path.is_relative_to(root) and path.is_file() for path in paths))
        result = resources(self.checkpoint)
        self.assertTrue(result['within_limit'], result['counted_bytes'])


class AssetAccounting(unittest.TestCase):
    def test_nested_configuration_assets_are_included(self):
        with tempfile.TemporaryDirectory() as temp:
            bundle = Path(temp)
            np.savez(bundle / 'weights.npz', w=np.ones(3, dtype=np.float32))
            (bundle / 'member.json').write_text('{"weights": "weights.npz"}')
            (bundle / 'config.json').write_text('{"members": [{"config": "member.json"}]}')
            _, paths = inference_files(bundle / 'config.json')
            self.assertEqual({path.name for path in paths}, {'config.json', 'member.json', 'weights.npz'})

    def test_config_escape_is_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            bundle = root / 'bundle'
            bundle.mkdir()
            (root / 'outside.npz').write_bytes(b'not a model')
            (bundle / 'config.json').write_text('{"weights": "../outside.npz"}')
            with self.assertRaisesRegex(ValueError, 'escapes'):
                inference_files(bundle)

    def test_compressed_arrays_are_counted_uncompressed(self):
        with tempfile.TemporaryDirectory() as temp:
            bundle = Path(temp)
            np.savez_compressed(bundle / 'weights.npz', w=np.zeros(10000, dtype=np.float32))
            (bundle / 'config.json').write_text('{"weights": "weights.npz"}')
            result = resources(bundle)
            self.assertGreater(result['uncompressed_bytes'], result['disk_bytes'])
            self.assertEqual(result['raw_payload_bytes'], 40000 + (bundle / 'config.json').stat().st_size)
            self.assertGreaterEqual(result['counted_bytes'], result['uncompressed_bytes'])

    def test_freeze_detects_changed_source_and_assets(self):
        import verify
        with tempfile.TemporaryDirectory() as temp:
            package = Path(temp)
            code = package / 'code'
            code.mkdir()
            (code / 'submission.py').write_text('def predict(*args): return []\n')
            (code / 'official.py').write_text('PROTOCOL = "test"\n')
            (code / 'PACKAGE_MANIFEST.json').write_text(json.dumps({
                'protocol': 'test', 'files': {'code/official.py': sha256(code / 'official.py')}}))
            bundle = code / 'runs/model'
            bundle.mkdir(parents=True)
            np.savez(bundle / 'weights.npz', w=np.ones(3, dtype=np.float32))
            (bundle / 'config.json').write_text('{"weights": "weights.npz"}')
            freeze = package / 'freeze.json'
            with patch.object(verify, 'CODE', code), patch.object(verify, 'PACKAGE', package):
                freeze.write_text(json.dumps(snapshot(bundle)))
                assert_frozen(bundle, freeze)
                np.savez(bundle / 'weights.npz', w=np.zeros(3, dtype=np.float32))
                with self.assertRaisesRegex(ValueError, 'assets'):
                    assert_frozen(bundle, freeze)
                np.savez(bundle / 'weights.npz', w=np.ones(3, dtype=np.float32))
                (code / 'submission.py').write_text('def predict(*args): return [0]\n')
                with self.assertRaisesRegex(ValueError, 'code_sha256'):
                    assert_frozen(bundle, freeze)


if __name__ == '__main__':
    unittest.main()
