"""RFF export parity and reference-free candidate-order behavior."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import features
import kernel_model as km


class KernelTests(unittest.TestCase):
    @staticmethod
    def fixture():
        rng = np.random.default_rng(4)
        bank = [{'id': str(i), 'question': 'There are 2 bags with 3 marbles each.',
                 'candidates': [{'index': j, 'text': f'2*3 = {6+j}\n#### {6+j}'} for j in range(4)]}
                for i in range(8)]
        arrays = {'embeddings': rng.normal(size=(8, 4, 1024)).astype(np.float32)}
        f, _ = features.extract(bank, arrays)
        x, numeric = km._inputs(f, 'embedding')
        y = np.tile([True, False, True, False], (8, 1))
        weights = km.projection(x, numeric, dict(m=32, gamma=1.), 17)
        phi, _ = km._basis(x, numeric, weights)
        weights, _ = km.fit_linear(phi, y, weights, 1.)
        return bank, arrays, f, x, numeric, phi, weights

    def test_inference_import_does_not_load_sklearn(self):
        result = subprocess.run([sys.executable, '-c',
            'import sys;import kernel_model;assert "sklearn" not in sys.modules'],
            cwd=Path(__file__).resolve().parents[1], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)

    def test_sklearn_coefficient_export_parity(self):
        from sklearn.linear_model import LogisticRegression
        _, _, _, x, numeric, phi, weights = self.fixture()
        y = np.tile([True, False, True, False], (8, 1))
        model = LogisticRegression(C=1., max_iter=500, tol=1e-5, solver='lbfgs').fit(phi, y.reshape(-1))
        expected = model.decision_function(phi).reshape(8, 4)
        np.testing.assert_allclose(km.numpy_scores(x, numeric, weights), expected, atol=2e-5, rtol=2e-5)

    def test_score_checkpoint_permutation_and_empty(self):
        bank, arrays, f, x, numeric, _, weights = self.fixture()
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp)/'config.json'
            np.savez(Path(tmp)/'weights.npz', **weights)
            path.write_text(json.dumps(dict(mode='embedding', numeric=True, weights='weights.npz')))
            expected = km.numpy_scores(x, numeric, weights)
            np.testing.assert_allclose(km.score(bank, arrays, path, f), expected, atol=1e-6)
            permutation = [3, 1, 0, 2]
            moved = [dict(row, id='changed', candidates=[row['candidates'][i] for i in permutation]) for row in bank]
            actual = km.score(moved, {'embeddings': arrays['embeddings'][:, permutation]}, path)
            np.testing.assert_allclose(actual, expected[:, permutation], atol=1e-5)
            self.assertEqual(km.score([], {'embeddings': np.empty((0, 4, 1024))}, path).shape, (0, 4))

    def test_stats_are_fitted_only_from_supplied_rows(self):
        _, _, _, x, numeric, _, _ = self.fixture()
        a = km.projection(x[:3], numeric[:3], dict(m=16, gamma=.25), 17)
        expected = x[:3].reshape(-1, 1024).mean(0, dtype=np.float64).astype(np.float32)
        np.testing.assert_array_equal(a['mean'], expected)
        b = km.projection(x[:3], numeric[:3], dict(m=16, gamma=.25), 17)
        np.testing.assert_array_equal(a['projection'], b['projection'])
        self.assertTrue(all(np.isfinite(value).all() for value in a.values()))


if __name__ == '__main__':
    unittest.main()
