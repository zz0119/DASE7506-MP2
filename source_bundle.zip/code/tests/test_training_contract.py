"""Export and held-out-label isolation checks for the neural/fusion training path."""
import unittest
from unittest.mock import patch
import json
from pathlib import Path
import sys
import tempfile

import numpy as np


class TrainingContract(unittest.TestCase):
    def test_resume_rejects_same_name_with_changed_recipe(self):
        import train
        bank = [{'id': 'a', 'question': 'What is one plus one?',
                 'candidates': [{'index': i, 'text': '1+1=2\n#### 2'} for i in range(4)]}]
        arrays = {'embeddings': np.zeros((1, 4, 1024), dtype=np.float32)}
        old = dict(mode='combined', width=8, objective='bce', dropout=.2)
        new = dict(old, dropout=.3)
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp)
            recipes = output / 'recipes.json'
            recipes.write_text(json.dumps([new]))
            name = train.name_for(old, 17)
            self.assertEqual(name, train.name_for(new, 17))
            (output / f'{name}.json').write_text(json.dumps(dict(recipe=old, training_epochs=70)))
            argv = ['train.py', '--output', str(output), '--recipes', str(recipes), '--seeds', '17']
            with patch.object(sys, 'argv', argv), \
                 patch.object(train, 'load_inputs', return_value=(bank, arrays)), \
                 patch.object(train, 'references', return_value=np.ones((1, 4), dtype=bool)), \
                 patch.object(train, 'fit', side_effect=AssertionError('resume must not train')):
                with self.assertRaisesRegex(ValueError, 'existing recipe/features/epoch budget differ'):
                    train.main()

    def test_context_and_plain_neural_inference_match_training_export(self):
        import torch
        from train import Ranker, numpy_scores, same_mask
        from submission import mlp_scores

        rng = np.random.default_rng(70)
        x = rng.normal(size=(5, 4, 7)).astype(np.float32)
        answers = [['1', '2', '1', None] for _ in x]
        same = same_mask(answers)
        mean = rng.normal(size=7).astype(np.float32)
        scale = rng.uniform(.2, 2, size=7).astype(np.float32)
        for context in (False, True):
            with self.subTest(context=context):
                torch.manual_seed(33)
                model = Ranker(7, 11, .3, context=context).eval()
                weights = {'mean': mean, 'scale': scale}
                for k, layer in enumerate((model.first, model.second, model.last)):
                    weights[f'w{k}'] = layer.weight.detach().numpy().T.copy()
                    weights[f'b{k}'] = layer.bias.detach().numpy().copy()
                with torch.no_grad():
                    expected = model(torch.from_numpy((x-mean)/scale), torch.from_numpy(same)).numpy()
                np.testing.assert_allclose(numpy_scores(x, same, weights, context), expected,
                                           atol=2e-6, rtol=2e-6)
                np.testing.assert_allclose(mlp_scores(x, answers, weights, context), expected,
                                           atol=2e-6, rtol=2e-6)

    def test_fixed_epoch_oof_weights_ignore_heldout_labels(self):
        from train import fit

        rng = np.random.default_rng(26)
        x = rng.normal(size=(12, 4, 7)).astype(np.float32)
        vx = rng.normal(size=(3, 4, 7)).astype(np.float32)
        y = np.tile([True, False, False, False], (12, 1))
        vy = np.tile([True, False, False, False], (3, 1))
        answers = [['1', '2', '3', '4'] for _ in x]
        va = [['1', '2', '3', '4'] for _ in vx]
        recipe = dict(width=8, dropout=.2, objective='pair', context=True)
        first, _, _, _ = fit(x, y, answers, vx, vy, va, recipe, seed=123, fixed_epoch=3)
        changed, _, _, _ = fit(x, y, answers, vx, np.roll(vy, 1, axis=1), va,
                                recipe, seed=123, fixed_epoch=3)
        for name in first:
            np.testing.assert_array_equal(first[name], changed[name])

    def test_fusion_prefers_correct_member_and_is_offset_invariant(self):
        from ensemble import optimize

        y = np.tile([True, False, False, False], (8, 1))
        hard = np.ones(len(y), dtype=bool)
        good = np.tile([3., -1., 0., .5], (len(y), 1))
        bad = -good
        oof = np.stack([good, bad])
        offsets = np.arange(2*len(y)).reshape(2, len(y), 1)*10.
        for objective in ('set', 'pair'):
            with self.subTest(objective=objective):
                weight, scale, _ = optimize(oof, y, hard, objective=objective)
                other_weight, other_scale, _ = optimize(oof+offsets, y, hard, objective=objective)
                self.assertGreater(weight[0], 0)
                self.assertLess(weight[1], 1e-6)
                np.testing.assert_allclose(scale, other_scale, atol=1e-9)
                np.testing.assert_allclose(weight, other_weight, atol=1e-8)


if __name__ == '__main__':
    unittest.main()
