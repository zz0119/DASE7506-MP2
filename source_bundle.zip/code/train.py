"""Reproducible train-only neural ranking and question-grouped OOF training."""
import argparse
import copy
import json
import os
from pathlib import Path
import time

for _key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
             'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_key] = os.environ.get('MP2_TRAIN_THREADS', '2')

import numpy as np
import torch
from torch import nn
from common import DATA, load_inputs, parse_answer, read_jsonl
from features import select

torch.set_num_threads(int(os.environ.get('MP2_TRAIN_THREADS', '2')))
torch.set_num_interop_threads(1)


def references(bank, split):
    if split not in ('train', 'validation'):
        raise ValueError('Training/development cannot open test references')
    refs = read_jsonl(DATA / f'gsm8k_{split}.jsonl')
    if [r['id'] for r in refs] != [r['id'] for r in bank]:
        raise ValueError('Reference alignment mismatch')
    y = np.array([[parse_answer(c['text']) is not None and
                   parse_answer(c['text']) == parse_answer(ref['answer'])
                   for c in row['candidates']] for row, ref in zip(bank, refs)])
    if not y.any(axis=1).all():
        raise ValueError('Every training group must have a correct candidate')
    return y


def hard_mask(answers):
    return np.array([len({a for a in row if a is not None}) >= 2 for row in answers])


def same_mask(answers):
    return np.array([[[a is not None and a == b for b in row] for a in row]
                     for row in answers], dtype=np.float32)


def metrics(scores, answers, y, pooling=0.):
    pred = select(scores, answers, pooling)
    hits = y[np.arange(len(y)), pred]
    hard = hard_mask(answers)
    return dict(correct=int(hits.sum()), n=len(hits), accuracy=float(100*hits.mean()),
                hard_correct=int(hits[hard].sum()), hard_n=int(hard.sum()),
                hard_accuracy=float(100*hits[hard].mean()) if hard.any() else 100.)


def metric_key(m):
    return m['hard_correct'], m['correct']


class Ranker(nn.Module):
    def __init__(self, dim, width, dropout, context=False, hidden=64):
        super().__init__()
        self.context = context
        self.first = nn.Linear(dim, width)
        self.drop = nn.Dropout(dropout)
        self.second = nn.Linear(width*(4 if context else 1), hidden)
        self.last = nn.Linear(hidden, 1)

    def forward(self, x, same):
        h = self.drop(torch.relu(self.first(x)))
        if self.context:
            group = h.mean(dim=1, keepdim=True).expand_as(h)
            maximum = h.max(dim=1, keepdim=True).values.expand_as(h)
            same_mean = (same @ h) / same.sum(-1, keepdim=True).clamp_min(1)
            h = torch.cat((h, group, maximum, same_mean-h), dim=-1)
        return self.last(torch.relu(self.second(h))).squeeze(-1)


def numpy_scores(x, same, weights, context=False):
    h = np.maximum(((x-weights['mean'])/weights['scale']) @ weights['w0'] + weights['b0'], 0)
    if context:
        group = np.broadcast_to(h.mean(1, keepdims=True), h.shape)
        maximum = np.broadcast_to(h.max(1, keepdims=True), h.shape)
        same_mean = (same @ h) / np.maximum(same.sum(-1, keepdims=True), 1)
        h = np.concatenate((h, group, maximum, same_mean-h), axis=-1)
    h = np.maximum(h @ weights['w1'] + weights['b1'], 0)
    return (h @ weights['w2'] + weights['b2'])[..., 0]


def fit(x, y, answers, vx, vy, va, recipe, seed, epochs=70, fixed_epoch=None):
    torch.manual_seed(seed)
    mean = x.mean((0, 1), dtype=np.float64).astype('float32')
    scale = x.std((0, 1), dtype=np.float64).clip(recipe.get('scale_floor', .03)).astype('float32')
    z, vz = torch.from_numpy((x-mean)/scale), torch.from_numpy((vx-mean)/scale)
    same, vsame = torch.from_numpy(same_mask(answers)), torch.from_numpy(same_mask(va))
    yt = torch.from_numpy(y.astype('float32'))
    hard = torch.from_numpy(hard_mask(answers))
    if recipe.get('attention'):
        import attention_model
        model = attention_model.build_model(x.shape[-1], recipe['width'], recipe.get('dropout', .25))
    else:
        model = Ranker(x.shape[-1], recipe['width'], recipe.get('dropout', .25),
                       recipe.get('context', False), recipe.get('hidden', 64))
    optimizer = torch.optim.AdamW(model.parameters(), lr=recipe.get('lr', .0007),
                                 weight_decay=recipe.get('decay', .03))
    ema_model = copy.deepcopy(model) if recipe.get('ema') else None
    best_key, best = (-1, -1), None
    history = []
    tick = time.perf_counter()
    for epoch in range(1, (fixed_epoch or epochs)+1):
        model.train()
        total_loss = 0.
        for idx in torch.randperm(len(y)).split(128):
            batch = z[idx]
            if recipe.get('input_noise', 0.):
                batch = batch + recipe['input_noise']*torch.randn_like(batch)
            s = model(batch, same[idx])
            target = yt[idx]
            bce = nn.functional.binary_cross_entropy_with_logits(s, target, reduction='none').mean(1)
            objective = recipe['objective']
            if objective == 'set':
                loss = torch.logsumexp(s, 1)-torch.logsumexp(s.masked_fill(~target.bool(), -torch.inf), 1)
            elif objective == 'pair':
                pairs = target.bool().unsqueeze(2) & ~target.bool().unsqueeze(1)
                pair_loss = (nn.functional.softplus(-(s.unsqueeze(2)-s.unsqueeze(1))) * pairs).sum((1,2))
                pair_loss = pair_loss / pairs.sum((1,2)).clamp_min(1)
                loss = bce + recipe.get('pair_weight', .5)*pair_loss
            else:
                loss = bce
            weight = torch.where(hard[idx], 1., recipe.get('easy_weight', 1.))
            loss = (loss*weight).mean()
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.)
            optimizer.step()
            if ema_model is not None:
                with torch.no_grad():
                    for averaged, current in zip(ema_model.parameters(), model.parameters()):
                        averaged.lerp_(current, 1-recipe['ema'])
            total_loss += loss.item()*len(idx)
        if fixed_epoch or epoch % 5 == 0:
            if fixed_epoch and epoch != fixed_epoch:
                continue
            evaluated = ema_model if ema_model is not None else model
            evaluated.eval()
            with torch.no_grad():
                torch_scores = evaluated(vz, vsame).numpy()
            if recipe.get('attention'):
                weights = attention_model.export(evaluated, mean, scale)
                scores = attention_model.numpy_scores(vx, same_mask(va), weights)
            else:
                weights = {'mean': mean.copy(), 'scale': scale.copy()}
                for k, layer in enumerate((evaluated.first, evaluated.second, evaluated.last)):
                    weights[f'w{k}'] = layer.weight.detach().numpy().T.copy()
                    weights[f'b{k}'] = layer.bias.detach().numpy().copy()
                scores = numpy_scores(vx, same_mask(va), weights, recipe.get('context', False))
            if not np.allclose(torch_scores, scores, rtol=2e-4, atol=2e-4):
                raise ValueError('NumPy export differs from the training model')
            m = metrics(scores, va, vy)
            history.append(dict(epoch=epoch, loss=total_loss/len(y), **m))
            if fixed_epoch or metric_key(m) > best_key:
                best_key = metric_key(m)
                best = (weights, scores.copy(), epoch, m)
    weights, scores, epoch, m = best
    exported = (attention_model.numpy_scores(vx, same_mask(va), weights) if recipe.get('attention')
                else numpy_scores(vx, same_mask(va), weights, recipe.get('context', False)))
    if not np.allclose(scores, exported, rtol=2e-4, atol=2e-4):
        raise ValueError('NumPy export differs from the training model')
    if select(scores, va) != select(exported, va):
        raise ValueError('NumPy export changes selected candidates')
    return weights, exported, dict(epoch=epoch, fit_seconds=time.perf_counter()-tick, **m), history


def recipe_list():
    recipes = []
    for mode in ('combined', 'advanced', 'context'):
        for objective in ('bce', 'set', 'pair'):
            for width in (128, 256, 512):
                recipes.append(dict(mode=mode, width=width, objective=objective,
                                    decay=.03, dropout=.25))
    for mode in ('advanced', 'context'):
        for width in (128, 256):
            for objective in ('bce', 'pair'):
                recipes.append(dict(mode=mode, width=width, objective=objective,
                                    context=True, decay=.03, dropout=.25))
        recipes.append(dict(mode=mode, width=256, objective='pair', easy_weight=.25,
                            context=True, decay=.03, dropout=.25))
    return recipes


def name_for(recipe, seed):
    suffix = '-ctx' if recipe.get('context') else ''
    if recipe.get('easy_weight', 1.) < 1:
        suffix += '-hard' if recipe['easy_weight'] == .25 else f"-hard{recipe['easy_weight']:g}"
    suffix += '-attn' if recipe.get('attention') else ''
    suffix += '-ema' if recipe.get('ema') else ''
    return f"neural-{recipe['mode']}-{recipe['width']}-{recipe['objective']}{suffix}-{seed}"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, default=Path('runs/search'))
    p.add_argument('--seeds', type=int, nargs='+', default=[17])
    p.add_argument('--epochs', type=int, default=70)
    p.add_argument('--modes', nargs='+', default=['combined', 'advanced', 'context'])
    p.add_argument('--recipes', type=Path, help='Explicit list of recipes instead of default grid')
    p.add_argument('--oof', type=Path, help='Model JSON to refit with grouped three-fold OOF')
    args = p.parse_args()
    import advanced_features as af
    bank, arrays = load_inputs('train')
    vb, varrays = load_inputs('validation')
    f, answers = af.extract(bank, arrays)
    vf, va = af.extract(vb, varrays)
    y, vy = references(bank, 'train'), references(vb, 'validation')
    args.output.mkdir(parents=True, exist_ok=True)
    matrices = {}
    def inputs(mode):
        if mode not in matrices:
            matrices[mode] = af.matrix(f, mode), af.matrix(vf, mode)
        return matrices[mode]
    if args.oof:
        from sklearn.model_selection import StratifiedKFold
        config = json.loads(args.oof.read_text())
        recipe, seed = config['recipe'], config['seed']
        x, vx = inputs(recipe['mode'])
        stratify = hard_mask(answers).astype(int)*5 + y.sum(1)
        oof = np.zeros(y.shape, dtype=np.float32)
        fold_records = []
        folds = StratifiedKFold(3, shuffle=True, random_state=17)
        for fold, (ti, hi) in enumerate(folds.split(x, stratify)):
            ta, ha = [answers[i] for i in ti], [answers[i] for i in hi]
            weights, scores, result, _ = fit(x[ti], y[ti], ta, x[hi], y[hi], ha,
                                             recipe, seed+fold, fixed_epoch=config['epoch'])
            oof[hi] = scores
            fold_records.append(dict(fold=fold, **result))
            print(json.dumps(dict(name=config['name'], fold=fold, **result)), flush=True)
        np.save(args.output / f"{config['name']}-oof.npy", oof)
        (args.output / f"{config['name']}-oof.json").write_text(json.dumps(dict(
            name=config['name'], folds=fold_records, metrics=metrics(oof, answers, y),
            fit_scope='train only; question-grouped folds', seed=17), indent=2)+'\n')
        return
    recipes = json.loads(args.recipes.read_text()) if args.recipes else recipe_list()
    for recipe in recipes:
        if recipe['mode'] not in args.modes:
            continue
        x, vx = inputs(recipe['mode'])
        for seed in args.seeds:
            name = name_for(recipe, seed)
            if (args.output / f'{name}.json').exists():
                previous = json.loads((args.output / f'{name}.json').read_text())
                feature_matches = (recipe['mode'] in ('combined', 'embedding', 'style') or
                                   previous.get('feature_version') == af.FEATURE_VERSION)
                if (previous.get('recipe') != recipe or not feature_matches or
                        previous.get('training_epochs', 70) != args.epochs):
                    raise ValueError(f'{name}: existing recipe/features/epoch budget differ; use a new output directory')
                continue
            weights, scores, result, history = fit(x, y, answers, vx, vy, va, recipe, seed, args.epochs)
            np.savez(args.output / f'{name}.npz', **weights)
            np.save(args.output / f'{name}-scores.npy', scores)
            pool_records = [dict(pooling=p, **metrics(scores, va, vy, p)) for p in (0., .5, 1.)]
            kind = 'attention_mlp' if recipe.get('attention') else ('context_mlp' if recipe.get('context') else 'mlp')
            config = dict(name=name, kind=kind,
                          mode=recipe['mode'], weights=f'{name}.npz', seed=seed,
                          recipe=recipe, feature_version=af.FEATURE_VERSION, training_epochs=args.epochs,
                          **result, pooling=0., pooling_metrics=pool_records)
            (args.output / f'{name}.json').write_text(json.dumps(config, indent=2)+'\n')
            with (args.output / 'experiments.jsonl').open('a') as out:
                out.write(json.dumps(config)+'\n')
            with (args.output / 'epochs.jsonl').open('a') as out:
                for item in history:
                    out.write(json.dumps(dict(name=name, **item))+'\n')
            print(json.dumps({k:v for k,v in config.items() if k != 'pooling_metrics'}), flush=True)


if __name__ == '__main__':
    main()
