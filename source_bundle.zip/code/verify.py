"""Audit unchanged official tools, inference assets and fresh-process evaluation.

The test bank is scored only by an explicit ``measure --split test`` command
against a matching, previously written freeze manifest.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import zipfile

import numpy as np


CODE = Path(__file__).resolve().parent
PACKAGE = CODE.parent
LIMIT_BYTES = 16 * 2**20
REFERENCE_THREADS = 4
ASSET_KEYS = frozenset(('weights', 'config', 'vocabulary', 'file', 'model_file'))
THREAD_ENV = ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS',
              'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS', 'BLIS_NUM_THREADS')


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def contained(path, root):
    path, root = Path(path).resolve(), Path(root).resolve()
    if not path.is_relative_to(root):
        raise ValueError(f'Asset escapes checkpoint directory: {path}')
    if not path.is_file():
        raise ValueError(f'Missing asset: {path}')
    return path


def inference_files(checkpoint):
    """Return bundle root and all assets; reject escaping config references.

    A dedicated directory counts every file, including unreferenced files. For
    a single config, follow weights/config/vocabulary/file/model_file references.
    """
    checkpoint = Path(checkpoint).resolve()
    root = checkpoint if checkpoint.is_dir() else checkpoint.parent
    if checkpoint.is_dir():
        seeds = []
        for entry in checkpoint.rglob('*'):
            if entry.is_symlink() and not entry.resolve().is_relative_to(root):
                raise ValueError(f'Asset symlink escapes checkpoint directory: {entry}')
            if entry.is_file():
                seeds.append(entry)
    else:
        seeds = [checkpoint]
    paths = set()

    def references(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if key in ASSET_KEYS and isinstance(item, str):
                    yield item
                else:
                    yield from references(item)
        elif isinstance(value, list):
            for item in value:
                yield from references(item)

    def visit(path):
        path = contained(path, root)
        if path in paths:
            return
        paths.add(path)
        if path.suffix.lower() == '.json':
            for reference in references(json.loads(path.read_text())):
                if Path(reference).is_absolute():
                    raise ValueError(f'Asset references must be relative: {reference}')
                visit(path.parent / reference)

    for path in seeds:
        visit(path)
    if not paths:
        raise ValueError('Checkpoint directory contains no inference assets')
    return root, sorted(paths)


def resources(checkpoint):
    root, paths = inference_files(checkpoint)
    records = []
    for path in paths:
        disk = path.stat().st_size
        unpacked, raw = disk, disk
        if path.suffix.lower() == '.npz':
            with zipfile.ZipFile(path) as archive:
                unpacked = sum(info.file_size for info in archive.infolist())
            with np.load(path, allow_pickle=False) as arrays:
                raw = sum(arrays[key].nbytes for key in arrays.files)
        elif path.suffix.lower() == '.npy':
            raw = np.load(path, allow_pickle=False, mmap_mode='r').nbytes
        records.append({'path': path.relative_to(root).as_posix(),
                        'sha256': sha256(path), 'disk_bytes': disk,
                        'uncompressed_bytes': unpacked, 'raw_payload_bytes': raw,
                        'counted_bytes': max(disk, unpacked)})
    totals = {key: sum(record[key] for record in records)
              for key in ('disk_bytes', 'uncompressed_bytes', 'raw_payload_bytes', 'counted_bytes')}
    return {'checkpoint': str(Path(checkpoint).resolve()), 'root': str(root),
            'files': records, **totals, 'limit_bytes': LIMIT_BYTES,
            'counted_mib': totals['counted_bytes'] / 2**20,
            'within_limit': totals['counted_bytes'] <= LIMIT_BYTES,
            'accounting': 'Per file max(disk, uncompressed); raw arrays plus non-array files also reported.'}


def official_hashes():
    manifest_path = CODE / 'PACKAGE_MANIFEST.json'
    manifest = json.loads(manifest_path.read_text())
    records, mismatches = {}, []
    for relative, expected in manifest['files'].items():
        # The supplied interface is explicitly intended for student replacement.
        if relative == 'code/submission.py':
            continue
        path = PACKAGE / relative
        actual = sha256(path) if path.is_file() else None
        records[relative] = actual
        if actual != expected:
            mismatches.append(relative)
    if mismatches:
        raise ValueError(f'Official package files changed or missing: {mismatches}')
    return {'protocol': manifest['protocol'], 'package_manifest_sha256': sha256(manifest_path),
            'files': records, 'intentional_exclusions': ['code/submission.py']}


def code_hashes():
    records = {}
    for path in CODE.rglob('*'):
        relative = path.relative_to(CODE)
        if any(part in ('.venv', '__pycache__', 'runs', 'data', '.git') for part in relative.parts):
            continue
        if path.is_file() and (path.suffix == '.py' or path.name.startswith('requirements')
                               or path.name in ('pyproject.toml', 'uv.lock')):
            records[relative.as_posix()] = sha256(path)
    return dict(sorted(records.items()))


def snapshot(checkpoint):
    assets = resources(checkpoint)
    if not assets['within_limit']:
        raise ValueError(f"Inference assets exceed 16 MiB: {assets['counted_bytes']} bytes")
    return {'schema': 'mp2-freeze-v1', 'official': official_hashes(),
            'code_sha256': code_hashes(), 'assets': assets}


def assert_frozen(checkpoint, freeze_path):
    frozen = json.loads(Path(freeze_path).read_text())
    current = snapshot(checkpoint)
    # Allow relocation of the whole reproducible package, but no content changes.
    for key in ('schema', 'official', 'code_sha256'):
        if frozen.get(key) != current[key]:
            raise ValueError(f'Frozen {key} no longer matches; freeze before final evaluation')
    if frozen['assets']['files'] != current['assets']['files']:
        raise ValueError('Frozen inference assets no longer match')
    return frozen


def hardware():
    result = {'platform': platform.platform(), 'machine': platform.machine(),
              'processor': platform.processor(), 'logical_cpus': os.cpu_count(),
              'python': platform.python_version(), 'numpy': np.__version__}
    if sys.platform == 'darwin':
        for name, field in (('machdep.cpu.brand_string', 'cpu_name'), ('hw.memsize', 'memory_bytes')):
            process = subprocess.run(['sysctl', '-n', name], capture_output=True, text=True)
            if process.returncode == 0:
                value = process.stdout.strip()
                result[field] = int(value) if field == 'memory_bytes' else value
    elif Path('/proc/cpuinfo').exists():
        for line in Path('/proc/cpuinfo').read_text().splitlines():
            if line.startswith('model name'):
                result['cpu_name'] = line.split(':', 1)[1].strip()
                break
    return result


def measure(checkpoint, split, output, freeze_path=None):
    if split == 'test' and freeze_path is None:
        raise ValueError('--freeze is required before scoring the final test bank')
    if freeze_path is not None:
        assert_frozen(checkpoint, freeze_path)
    else:
        snapshot(checkpoint)
    output = Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    predictions, score = output / f'{split}-predictions.json', output / f'{split}-score.json'
    commands = [
        [sys.executable, str(CODE / 'predict.py'), '--method', str(CODE / 'submission.py'),
         '--checkpoint', str(Path(checkpoint).resolve()), '--split', split, '--output', str(predictions)],
        [sys.executable, str(CODE / 'score_predictions.py'), '--split', split,
         '--predictions', str(predictions), '--output', str(score)],
    ]
    env = dict(os.environ, **{key: str(REFERENCE_THREADS) for key in THREAD_ENV},
               PYTHONDONTWRITEBYTECODE='1')
    executions = []
    total_start = time.perf_counter()
    for name, command in zip(('prediction', 'scoring'), commands):
        start = time.perf_counter()
        process = subprocess.run(command, cwd=CODE, env=env, capture_output=True, text=True)
        elapsed = time.perf_counter() - start
        (output / f'{split}-{name}.log').write_text(process.stdout + process.stderr)
        executions.append({'phase': name, 'command': command, 'wall_seconds': elapsed,
                           'returncode': process.returncode})
        if process.returncode:
            raise RuntimeError(f'{name} failed; see {output / f"{split}-{name}.log"}')
    total = time.perf_counter() - total_start
    result = {'split': split, 'hardware': hardware(), 'threads': REFERENCE_THREADS,
              'thread_environment': {key: env[key] for key in THREAD_ENV},
              'executions': executions, 'fresh_process_wall_seconds': sum(x['wall_seconds'] for x in executions),
              'including_driver_io_wall_seconds': total, 'local_under_30_seconds': total <= 30,
              'reference_eligibility': 'Local measurement only; reference Xeon Platinum 8457C determines eligibility.',
              'official_score': json.loads(score.read_text()), 'assets': resources(checkpoint),
              'freeze_sha256': sha256(freeze_path) if freeze_path is not None else None}
    (output / f'{split}-measurement.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    for name in ('resources', 'freeze', 'measure'):
        command = commands.add_parser(name)
        command.add_argument('--checkpoint', type=Path, required=True)
        command.add_argument('--output', type=Path, required=name != 'resources')
        if name == 'measure':
            command.add_argument('--split', choices=('validation', 'test'), required=True)
            command.add_argument('--freeze', type=Path)
    args = parser.parse_args()
    if args.command == 'resources':
        result = resources(args.checkpoint)
    elif args.command == 'freeze':
        result = snapshot(args.checkpoint)
        root = Path(result['assets']['root'])
        if args.output.resolve().is_relative_to(root):
            raise ValueError('Save the freeze manifest outside the checkpoint directory')
        result['frozen_at_utc'] = datetime.now(timezone.utc).isoformat()
    else:
        result = measure(args.checkpoint, args.split, args.output, args.freeze)
    if args.command != 'measure' and args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    if args.command == 'resources' and not result['within_limit']:
        raise SystemExit(1)


if __name__ == '__main__':
    main()
