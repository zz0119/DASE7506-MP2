"""Restore the exact supplied course data; never download model weights."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import urllib.request

ROOT = Path(__file__).resolve().parent
COMMIT = 'bb801f4f2e7629d270df765ab12c333b2dc616bb'
BASE = f'https://raw.githubusercontent.com/xudongwu-0/DASE7506-MP2/{COMMIT}/'

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-data', type=Path, help='Optional existing official code/data directory for offline setup')
    args = p.parse_args()
    manifest = json.loads((ROOT/'code/PACKAGE_MANIFEST.json').read_text())
    records = [(name, sha) for name, sha in manifest['files'].items() if name.startswith('code/data/')]
    for relative, expected in records:
        path = ROOT/relative
        if path.is_file() and digest(path) == expected:
            print('Verified', relative)
            continue
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_name(path.name+'.download')
        try:
            if args.source_data:
                source = args.source_data/Path(relative).relative_to('code/data')
                shutil.copyfile(source, temporary)
            else:
                request = urllib.request.Request(BASE+relative, headers={'User-Agent':'DASE7506-MP2-data-setup'})
                with urllib.request.urlopen(request, timeout=120) as response, temporary.open('wb') as output:
                    shutil.copyfileobj(response, output)
            if digest(temporary) != expected:
                raise ValueError(f'Official data hash mismatch: {relative}')
            temporary.replace(path)
            print('Restored', relative)
        finally:
            if temporary.exists():
                temporary.unlink()
    print('Official data ready. Prediction and scoring can now run offline.')

if __name__ == '__main__':
    main()
